# Guide Complet pour Générer l'APK - Garage Pro

## 🚀 Méthode 1 : Build en ligne (Recommandée pour débutants)

### Étape 1 : Créer un compte Expo
1. Aller sur https://expo.dev
2. Cliquer sur "Sign Up" 
3. Créer un compte gratuit

### Étape 2 : Uploader le projet sur Expo
```bash
cd mobile
npx expo login
# Entrer email/mot de passe Expo

npx expo publish
```

### Étape 3 : Générer l'APK depuis le navigateur
1. Aller sur https://expo.dev/projects
2. Cliquer sur votre projet
3. Cliquer sur "Build" dans le menu de gauche
4. Cliquer sur "Create Build"
5. Sélectionner :
   - **Platform**: Android
   - **Build Type**: APK
   - **Channel**: preview
6. Cliquer sur "Start Build"

### Étape 4 : Télécharger l'APK
- Attendre 5-15 minutes
- Cliquer sur "Download Build"
- Installer sur votre téléphone Android

---

## 🛠️ Méthode 2 : Build local avec EAS CLI

### Prérequis Windows
```bash
# 1. Installer Node.js (si pas déjà fait)
# Télécharger sur https://nodejs.org/ (version 18+)

# 2. Ouvrir PowerShell ou CMD en tant qu'administrateur
```

### Installation des outils
```bash
cd mobile

# Installer Expo CLI
npm install -g expo-cli

# Installer EAS CLI
npm install -g eas-cli

# Vérifier l'installation
node -v
npm -v
eas --version
```

### Connexion à Expo
```bash
# Se connecter
eas login

# Entrer :
# - Email : votre email Expo
# - Mot de passe : votre mot de passe

# Vérifier la connexion
eas whoami
```

### Configuration du projet (première fois)
```bash
# Initialiser EAS Build
eas build:configure

# Répondre aux questions :
# - Platform : Android (sélectionner avec flèches)
# - Build Type : APK
```

### Génération de l'APK
```bash
# Build APK pour prévisualisation
eas build -p android --profile preview

# OU build production
eas build -p android --profile production

# Le terminal affichera un lien pour suivre le build
# Example: https://expo.dev/builds/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

---

## 🔥 Méthode 3 : Build local avec Android Studio (Avancé)

### Installation Android Studio
1. Télécharger Android Studio sur https://developer.android.com/studio
2. Installer avec les composants par défaut
3. Ouvrir Android Studio et attendre l'installation du SDK

### Configuration des variables d'environnement
```bash
# Dans PowerShell (administrateur)
[Environment]::SetEnvironmentVariable("ANDROID_HOME", "C:\Users\VotreNom\AppData\Local\Android\Sdk", "Machine")
[Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Android\Android Studio\jbr", "Machine")

# Redémarrer le terminal
```

### Build local
```bash
cd mobile

# Générer les fichiers Android
npx expo prebuild

# Ouvrir dans Android Studio
start android

# Dans Android Studio :
# 1. Cliquer sur "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)"
# 2. Attendre la fin du build
# 3. L'APK se trouve dans android/app/build/outputs/apk/debug/
```

---

## 📋 Commandes Rapides (Résumé)

```bash
# Installation complète
cd mobile
npm install -g expo-cli eas-cli
eas login

# Build APK
eas build -p android --profile preview

# ou avec expo publish (plus simple)
npx expo publish
# Puis aller sur https://expo.dev/builds
```

---

## ❓ Dépannage

### "eas: command not found"
```bash
# Réinstaller eas-cli
npm uninstall -g eas-cli
npm install -g eas-cli
```

### "Node.js not found"
- Installer Node.js depuis https://nodejs.org/
- Redémarrer le terminal

### Build échoue avec erreur de mémoire
```bash
# Augmenter la mémoire Node
export NODE_OPTIONS="--max-old-space-size=4096"
eas build -p android
```

### Google Play Services manquant
- Assurez-vous d'avoir ajouté `google-services.json` dans `mobile/`

---

## 📱 Installer l'APK sur le téléphone

1. Transférer le fichier `.apk` sur le téléphone
2. Ouvrir "Paramètres" > "Sécurité"
3. Activer "Sources inconnues"
4. Cliquer sur le fichier APK pour installer
