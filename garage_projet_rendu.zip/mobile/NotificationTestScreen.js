import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import * as Notifications from 'expo-notifications';
import { useNotifications, sendNotification } from './NotificationService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

// Palette de couleurs bleue
const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  tertiary: '#A7EBF2',
  background: '#011C40',
  card: '#023859',
  text: '#FFFFFF',
  textSecondary: '#B3B3B3',
  success: '#46d369',
  warning: '#ffa500',
  error: '#E50914',
};

export default function NotificationTestScreen({ navigation }) {
  const [token, setToken] = useState(null);
  const [fcmToken, setFcmToken] = useState(null);
  const [loading, setLoading] = useState(false);
  const [lastNotification, setLastNotification] = useState(null);
  
  const { 
    expoToken, 
    fcmToken: firebaseToken, 
    isReady, 
    initializeNotifications,
    subscribeToRealtimeNotifications
  } = useNotifications();

  useEffect(() => {
    initializeNotifications();
  }, [initializeNotifications]);

  useEffect(() => {
    const unsubscribe = subscribeToRealtimeNotifications();
    return () => unsubscribe && unsubscribe();
  }, [subscribeToRealtimeNotifications]);

  useEffect(() => {
    const notificationListener = Notifications.addNotificationReceivedListener(
      (notification) => {
        console.log('Notification reçue:', notification);
        setLastNotification({
          title: notification.request.content.title,
          body: notification.request.content.body,
          date: new Date().toLocaleTimeString(),
        });
      }
    );

    return () => {
      if (notificationListener) {
        Notifications.removeNotificationSubscription(notificationListener);
      }
    };
  }, []);

  useEffect(() => {
    if (expoToken) {
      setToken(expoToken);
    }
    if (firebaseToken) {
      setFcmToken(firebaseToken);
    }
  }, [expoToken, firebaseToken]);

  useEffect(() => {
    setupAndroidNotificationChannel();
  }, []);

  const setupAndroidNotificationChannel = async () => {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: COLORS.secondary,
      });

      await Notifications.setNotificationChannelAsync('repairs', {
        name: 'Réparations',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: COLORS.success,
      });
    }
  };

  const testLocalNotification = async () => {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Reparation terminee !',
        body: 'Votre vehicule est pret a etre recupere.',
        sound: true,
        data: { type: 'repair_ready', repairId: 123 },
        priority: 'high',
      },
      trigger: null,
    });
    Alert.alert('Succes', 'Notification test envoyee !');
  };

  const testProgressNotification = async () => {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Avancement',
        body: 'La vidange est terminee a 75%.',
        sound: false,
        data: { type: 'progress', repairId: 123 },
      },
      trigger: null,
    });
    Alert.alert('Succes', "Notification d'avancement envoyee !");
  };

  const testServerNotification = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      const user = userData ? JSON.parse(userData) : null;
      
      if (!user) {
        Alert.alert('Erreur', 'Veuillez vous connecter dabord');
        return;
      }

      setLoading(true);
      
      const result = await sendNotification(
        user.id,
        'Notification Serveur',
        'Ceci est une notification envoyee depuis le serveur Laravel'
      );
      
      if (result.success) {
        Alert.alert('Succes', 'Notification envoyee depuis le serveur !');
      } else {
        Alert.alert('Erreur', result.error || 'Impossible denvoyer la notification');
      }
    } catch (error) {
      Alert.alert('Erreur', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.headerIcon}>
            <Ionicons name="notifications" size={32} color="#FFFFFF" />
          </View>
          <Text style={styles.title}>Notifications</Text>
          <Text style={styles.subtitle}>Gerez vos alertes et mises a jour</Text>
        </View>

        {/* Status Card */}
        <View style={styles.statusCard}>
          <View style={styles.statusRow}>
            <View style={styles.statusInfo}>
              <Text style={styles.statusLabel}>Statut</Text>
              <Text style={styles.statusValue}>
                {(token || fcmToken) ? 'Activees' : 'Desactivees'}
              </Text>
            </View>
            <View style={[
              styles.statusIndicator,
              { backgroundColor: (token || fcmToken) ? COLORS.success : COLORS.error }
            ]}>
              <Ionicons 
                name={(token || fcmToken) ? 'checkmark' : 'close'} 
                size={20} 
                color="#FFFFFF" 
              />
            </View>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <View style={styles.miniStat}>
            <Ionicons name="time-outline" size={24} color={COLORS.warning} />
            <Text style={styles.miniStatValue}>En cours</Text>
          </View>
          <View style={styles.miniStat}>
            <Ionicons name="checkmark-circle-outline" size={24} color={COLORS.success} />
            <Text style={styles.miniStatValue}>Recues</Text>
          </View>
          <View style={styles.miniStat}>
            <Ionicons name="options-outline" size={24} color={COLORS.secondary} />
            <Text style={styles.miniStatValue}>Options</Text>
          </View>
        </View>

        {/* Test Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>TESTER</Text>
          
          <TouchableOpacity
            style={styles.testCard}
            onPress={testLocalNotification}
          >
            <View style={[styles.testIcon, { backgroundColor: COLORS.success + '20' }]}>
              <Ionicons name="checkmark-circle" size={24} color={COLORS.success} />
            </View>
            <View style={styles.testInfo}>
              <Text style={styles.testTitle}>Reparation prete</Text>
              <Text style={styles.testSubtitle}>Simule une notification de reparati...</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.testCard}
            onPress={testProgressNotification}
          >
            <View style={[styles.testIcon, { backgroundColor: COLORS.warning + '20' }]}>
              <Ionicons name="stats-chart" size={24} color={COLORS.warning} />
            </View>
            <View style={styles.testInfo}>
              <Text style={styles.testTitle}>Avancement</Text>
              <Text style={styles.testSubtitle}>Simule une notification davanceme...</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.testCard}
            onPress={testServerNotification}
            disabled={loading}
          >
            <View style={[styles.testIcon, { backgroundColor: COLORS.secondary + '20' }]}>
              <Ionicons name="cloud" size={24} color={COLORS.secondary} />
            </View>
            <View style={styles.testInfo}>
              <Text style={styles.testTitle}>Via Serveur</Text>
              <Text style={styles.testSubtitle}>Envoie une notification depuis Lar...</Text>
            </View>
            {loading ? (
              <ActivityIndicator color={COLORS.secondary} />
            ) : (
              <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
            )}
          </TouchableOpacity>
        </View>

        {/* Last Notification */}
        {lastNotification && (
          <View style={styles.lastCard}>
            <View style={styles.lastHeader}>
              <Ionicons name="time" size={16} color={COLORS.success} />
              <Text style={styles.lastHeaderText}>Derniere recue</Text>
              <Text style={styles.lastTime}>{lastNotification.date}</Text>
            </View>
            <Text style={styles.lastTitle}>{lastNotification.title}</Text>
            <Text style={styles.lastBody}>{lastNotification.body}</Text>
          </View>
        )}

        {/* Tokens Info */}
        {(token || fcmToken) && (
          <View style={styles.tokensSection}>
            <Text style={styles.sectionTitle}>INFORMATION</Text>
            <View style={styles.tokenCard}>
              <View style={styles.tokenRow}>
                <Ionicons name="key-outline" size={16} color={COLORS.secondary} />
                <Text style={styles.tokenLabel}>
                  {token ? 'Expo Push Token' : 'FCM Token'}
                </Text>
              </View>
              <Text style={styles.tokenValue} numberOfLines={2}>
                {(token || fcmToken).substring(0, 60)}...
              </Text>
            </View>
          </View>
        )}

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Les notifications sont gerees par</Text>
          <Text style={styles.footerSubtext}>Expo Notifications & Firebase Cloud Messaging</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  headerIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  statusCard: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusInfo: {
    flex: 1,
  },
  statusLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  statusValue: {
    fontSize: 20,
    fontWeight: '600',
    color: COLORS.text,
  },
  statusIndicator: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  miniStat: {
    flex: 1,
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  miniStatValue: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 8,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 12,
    letterSpacing: 1,
  },
  testCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  testIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  testInfo: {
    flex: 1,
  },
  testTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.text,
  },
  testSubtitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  lastCard: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: COLORS.success,
  },
  lastHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  lastHeaderText: {
    fontSize: 12,
    color: COLORS.success,
    marginLeft: 6,
    flex: 1,
  },
  lastTime: {
    fontSize: 11,
    color: COLORS.textSecondary,
  },
  lastTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 6,
  },
  lastBody: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  tokensSection: {
    marginBottom: 20,
  },
  tokenCard: {
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  tokenRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tokenLabel: {
    fontSize: 12,
    color: COLORS.secondary,
    marginLeft: 8,
  },
  tokenValue: {
    fontSize: 11,
    color: COLORS.textSecondary,
    fontFamily: 'monospace',
  },
  footer: {
    alignItems: 'center',
    paddingTop: 20,
  },
  footerText: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  footerSubtext: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 4,
    opacity: 0.6,
  },
});
