import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Dimensions
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Ionicons from '@expo/vector-icons/Ionicons';
import { AuthContext } from './App';

const { width } = Dimensions.get('window');

// Palette de couleurs bleue
const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  tertiary: '#A7EBF2',
  background: '#011C40',
  card: '#023859',
  text: '#FFFFFF',
  textSecondary: '#B3B3B3',
  success: '#46d369',
  warning: '#ffa500',
  error: '#E50914',
};

export default function ProfileScreen({ navigation }) {
  const { refreshAuthState } = useContext(AuthContext);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (error) {
      console.error('Erreur lors du chargement des données:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    console.log('Déconnexion initiée');
    setShowLogoutConfirm(true);
  };

  const confirmLogout = async () => {
    console.log('Déconnexion confirmée');
    setShowLogoutConfirm(false);
    
    try {
      await AsyncStorage.clear();
      console.log('AsyncStorage effacé');
      await refreshAuthState();
      console.log('État d\'authentification mis à jour');
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
    }
  };

  const cancelLogout = () => {
    console.log('Déconnexion annulée');
    setShowLogoutConfirm(false);
  };

  const getInitials = (name) => {
    if (!name) return '?';
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Chargement...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {showLogoutConfirm && (
        <View style={styles.overlay}>
          <View style={styles.confirmDialog}>
            <Ionicons name="log-out-outline" size={48} color={COLORS.secondary} />
            <Text style={styles.confirmTitle}>Déconnexion</Text>
            <Text style={styles.confirmMessage}>
              Voulez-vous vraiment vous déconnecter ?
            </Text>
            <View style={styles.confirmButtons}>
              <TouchableOpacity 
                style={[styles.confirmButton, styles.cancelButton]}
                onPress={cancelLogout}
              >
                <Text style={styles.cancelButtonText}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.confirmButton, styles.logoutButtonConfirm]}
                onPress={confirmLogout}
              >
                <Text style={styles.logoutButtonConfirmText}>Déconnecter</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}

      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {getInitials(user?.name || user?.email || '?')}
            </Text>
          </View>
          <Text style={styles.userName}>
            {user?.name || 'Utilisateur'}
          </Text>
          <Text style={styles.userEmail}>
            {user?.email || 'email@exemple.com'}
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>COMPTE</Text>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => alert('Fonctionnalité à venir')}
          >
            <View style={styles.menuItemLeft}>
              <Ionicons name="person-outline" size={22} color={COLORS.secondary} />
              <Text style={styles.menuItemText}>Modifier le profil</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => alert('Fonctionnalité à venir')}
          >
            <View style={styles.menuItemLeft}>
              <Ionicons name="lock-closed-outline" size={22} color={COLORS.secondary} />
              <Text style={styles.menuItemText}>Sécurité</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => alert('Fonctionnalité à venir')}
          >
            <View style={styles.menuItemLeft}>
              <Ionicons name="notifications-outline" size={22} color={COLORS.secondary} />
              <Text style={styles.menuItemText}>Notifications</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>AIDE</Text>
          
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => alert('Contactez le garage pour toute question.')}
          >
            <View style={styles.menuItemLeft}>
              <Ionicons name="help-circle-outline" size={22} color={COLORS.secondary} />
              <Text style={styles.menuItemText}>Centre d\'aide</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => alert('Garage Pro v1.0\nDéveloppé avec React Native & Laravel')}
          >
            <View style={styles.menuItemLeft}>
              <Ionicons name="information-circle-outline" size={22} color={COLORS.secondary} />
              <Text style={styles.menuItemText}>À propos</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Ionicons name="log-out-outline" size={22} color={COLORS.error} />
          <Text style={styles.logoutText}>Se déconnecter</Text>
        </TouchableOpacity>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Garage Pro © 2024</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: COLORS.textSecondary,
    fontSize: 16,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  confirmDialog: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 24,
    width: '80%',
    maxWidth: 320,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  confirmTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 16,
    marginBottom: 8,
  },
  confirmMessage: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  confirmButtons: {
    flexDirection: 'row',
    width: '100%',
    gap: 12,
  },
  confirmButton: {
    flex: 1,
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: COLORS.primary,
  },
  cancelButtonText: {
    color: COLORS.text,
    fontWeight: '600',
    fontSize: 14,
  },
  logoutButtonConfirm: {
    backgroundColor: COLORS.error,
  },
  logoutButtonConfirmText: {
    color: COLORS.text,
    fontWeight: '600',
    fontSize: 14,
  },
  header: {
    alignItems: 'center',
    paddingVertical: 32,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primary,
    marginBottom: 24,
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '700',
    color: 'white',
  },
  userName: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  section: {
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 8,
    marginLeft: 4,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemText: {
    color: COLORS.text,
    fontSize: 15,
    marginLeft: 12,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 16,
    borderWidth: 1,
    borderColor: COLORS.error,
  },
  logoutText: {
    color: COLORS.error,
    fontSize: 15,
    fontWeight: '600',
    marginLeft: 8,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  footerText: {
    color: COLORS.textSecondary,
    fontSize: 12,
  },
});
