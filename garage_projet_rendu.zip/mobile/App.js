import React, { createContext, useState, useEffect, useCallback } from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';
import NotificationTestScreen from './NotificationTestScreen';
import ReportScreen from './ReportScreen';
import RepairsScreen from './RepairsScreen';
import ProfileScreen from './ProfileScreen';
import RepairDetailScreen from './RepairDetailScreen';
import PaymentScreen from './PaymentScreen';

// Palette de couleurs bleue
const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  tertiary: '#A7EBF2',
  background: '#011C40',
  card: '#023859',
  text: '#FFFFFF',
  textSecondary: '#B3B3B3',
  success: '#46d369',
  warning: '#ffa500',
  error: '#E50914',
};

// Création du contexte d'authentification
const AuthContext = createContext();

// Thème sombre avec palette bleue
const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: COLORS.background, 
    card: COLORS.card,       
    text: COLORS.text,       
    border: COLORS.primary,     
    primary: COLORS.secondary,    
  },
};

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Icônes personnalisées pour les tabs
const TabIcon = ({ name, focused, iconName }) => {
  const iconSize = focused ? 28 : 24;
  const iconColor = focused ? COLORS.secondary : COLORS.textSecondary;
     
  return (
    <View style={styles.tabIconContainer}>
      <Ionicons 
        name={iconName} 
        size={iconSize} 
        color={iconColor} 
      />
    </View>
  );
};

// Stack pour les écrans principaux après connexion
function MainStack() {
  return (
    <Stack.Navigator 
      initialRouteName="Repairs"
      screenOptions={{
        headerShown: false,
        cardStyle: { backgroundColor: COLORS.background },
        gestureEnabled: false,
      }}
    >
      <Stack.Screen name="Repairs" component={RepairsScreen} />
      <Stack.Screen name="Report" component={ReportScreen} />
      <Stack.Screen name="RepairDetail" component={RepairDetailScreen} />
      <Stack.Screen name="Payment" component={PaymentScreen} />
      <Stack.Screen name="Notifications" component={NotificationTestScreen} />
    </Stack.Navigator>
  );
}

// Tab Navigator pour la navigation principale
function AppTabs() {
  console.log('🎯 AppTabs rendered');
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: COLORS.secondary,
        tabBarInactiveTintColor: COLORS.textSecondary,
        tabBarShowLabel: true,
        tabBarLabelStyle: styles.tabLabel,
      }}
    >
      <Tab.Screen 
        name="Accueil" 
        component={MainStack}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon name="Accueil" focused={focused} iconName="home" />
          ),
          tabBarLabel: 'Accueil',
        }}
      />
      <Tab.Screen 
        name="Réparations" 
        component={MainStack}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon name="Réparations" focused={focused} iconName="car" />
          ),
          tabBarLabel: 'Réparations',
        }}
      />
      <Tab.Screen 
        name="Notifications" 
        component={NotificationTestScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon name="Notifications" focused={focused} iconName="notifications" />
          ),
          tabBarLabel: 'Notifications',
        }}
      />
      <Tab.Screen 
        name="Profil" 
        component={ProfileScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon name="Profil" focused={focused} iconName="person" />
          ),
          tabBarLabel: 'Profil',
        }}
      />
    </Tab.Navigator>
  );
}

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [authKey, setAuthKey] = useState(0);

  // Fonction pour rafraîchir l'état d'authentification
  const refreshAuthState = useCallback(async () => {
    console.log('🔄 refreshAuthState called');
    try {
      const userData = await AsyncStorage.getItem('user');
      const wasLoggedIn = isLoggedIn;
      const willBeLoggedIn = !!userData;
      
      console.log('🔄 Before: isLoggedIn =', wasLoggedIn);
      console.log('🔄 After: isLoggedIn =', willBeLoggedIn);
      console.log('🔄 User data in AsyncStorage:', userData);
      
      setIsLoggedIn(willBeLoggedIn);
      setAuthKey(prev => {
        const newKey = prev + 1;
        console.log('🔄 New authKey:', newKey);
        return newKey;
      });
    } catch (error) {
      console.error('Error refreshing auth:', error);
    }
  }, [isLoggedIn]);

  // Valeur du contexte
  const authContextValue = {
    refreshAuthState,
  };

  useEffect(() => {
    const checkAuth = async () => {
      console.log('🔄 Initial checkAuth');
      try {
        const userData = await AsyncStorage.getItem('user');
        console.log('🔄 Initial user data:', userData ? 'found' : 'not found');
        if (userData) {
          setIsLoggedIn(true);
        }
      } catch (error) {
        console.error('Error checking auth:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  console.log('📱 App rendered - isLoggedIn:', isLoggedIn, ', authKey:', authKey);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.secondary} />
      </View>
    );
  }

  return (
    <AuthContext.Provider value={authContextValue}>
      <NavigationContainer 
        theme={MyTheme} 
        key={authKey}
      >
        <Stack.Navigator 
          screenOptions={{
            headerShown: false,
            cardStyle: { backgroundColor: COLORS.background }
          }}
        >
          {isLoggedIn ? (
            <>
              <Stack.Screen name="Main" component={AppTabs} />
            </>
          ) : (
            <>
              <Stack.Screen name="Login" component={LoginScreen} />
              <Stack.Screen name="Register" component={RegisterScreen} />
            </>
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </AuthContext.Provider>
  );
}

// Exporter le contexte pour utilisation dans les autres fichiers
export { AuthContext };
export default App;

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  tabBar: {
    backgroundColor: COLORS.card,
    borderTopWidth: 1,
    borderTopColor: COLORS.primary,
    height: 65,
    paddingBottom: 5,
    paddingTop: 8,
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 4,
  },
});
