import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView, ScrollView, ActivityIndicator, Linking, Platform, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

const EUR_TO_MGA = 4500;

const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  light: '#A7EBF2',
  dark: '#023859',
  background: '#011C40',
  card: '#023859',
  text: '#FFFFFF',
  textSecondary: '#A7EBF2',
  orange: '#FF9500',
  green: '#34C759',
  red: '#E50914',
};

export default function RepairDetailScreen({ route, navigation }) {
  const { repair } = route.params || {};
  const [currentRepair, setCurrentRepair] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showPhoneModal, setShowPhoneModal] = useState(false);

  const formatCost = (cost) => {
    if (!cost) return 'Non défini';
    const eur = parseFloat(cost);
    if (isNaN(eur)) return cost;
    const mga = Math.round(eur * EUR_TO_MGA);
    return mga.toLocaleString() + ' Ar';
  };

  useEffect(() => {
    if (repair) {
      setCurrentRepair(repair);
      setLoading(false);
    } else {
      loadRepairFromStorage();
    }
  }, [repair]);

  const loadRepairFromStorage = async () => {
    try {
      const repairsData = await AsyncStorage.getItem('repairs');
      if (repairsData) {
        const repairs = JSON.parse(repairsData);
        if (repairs.length > 0) {
          setCurrentRepair(repairs[0]);
        }
      }
      if (!currentRepair) {
        const demoRepair = {
          id: 'demo-1',
          vehicle: 'Toyota Camry 2020',
          client: 'Dupont Jean',
          issue: 'Révision générale',
          description: 'Vidange, filtres, contrôle des freins',
          status: 'progress',
          progress: 65,
          date: '2024-01-15',
          estimatedCost: 250,
          estimatedTime: '2-3 heures',
          garage: 'Garage Pro',
          garagePhone: '+33 1 23 45 67 89',
          garageAddress: '123 Rue Principale, Paris',
        };
        setCurrentRepair(demoRepair);
      }
    } catch (error) {
      console.error('Error loading repair:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return COLORS.orange;
      case 'progress': return COLORS.red;
      case 'done': return COLORS.green;
      default: return COLORS.textSecondary;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending': return 'En attente';
      case 'progress': return 'En cours';
      case 'done': return 'Terminé';
      default: return status;
    }
  };

  const getProgressColor = (progress) => {
    if (progress >= 75) return COLORS.green;
    if (progress >= 50) return COLORS.orange;
    if (progress >= 25) return COLORS.secondary;
    return COLORS.red;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Non définie';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch (e) { return dateString; }
  };

  const callGarage = () => setShowPhoneModal(true);

  const handleCall = () => {
    setShowPhoneModal(false);
    const phone = currentRepair?.garagePhone || '+33123456789';
    if (Platform.OS !== 'web') {
      Linking.openURL(`tel:${phone.replace(/\s/g, '')}`);
    } else {
      Alert.alert('Numéro', phone);
    }
  };

  if (loading) {
    return <SafeAreaView style={styles.container}><View style={styles.loadingContainer}><ActivityIndicator size="large" color={COLORS.secondary} /><Text style={styles.loadingText}>Chargement...</Text></View></SafeAreaView>;
  }

  if (!currentRepair) {
    return <SafeAreaView style={styles.container}><View style={styles.loadingContainer}><Text style={styles.loadingText}>Aucune réparation trouvée</Text></View></SafeAreaView>;
  }

  const statusColor = getStatusColor(currentRepair.status);
  const progressColor = getProgressColor(currentRepair.progress || 0);

  return (
    <SafeAreaView style={styles.container}>
      {showPhoneModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalIcon}><Ionicons name="call" size={48} color={COLORS.secondary} /></View>
            <Text style={styles.modalTitle}>Numéro du garage</Text>
            <Text style={styles.modalPhone}>{currentRepair?.garagePhone || '+33123456789'}</Text>
            <TouchableOpacity style={styles.modalCallButton} onPress={handleCall}><Text style={styles.modalCallButtonText}>Appeler</Text></TouchableOpacity>
            <TouchableOpacity style={styles.modalCloseButton} onPress={() => setShowPhoneModal(false)}><Text style={styles.modalCloseButtonText}>Fermer</Text></TouchableOpacity>
          </View>
        </View>
      )}

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#FFFFFF" /></TouchableOpacity>
          <Text style={styles.headerTitle}>Détails</Text>
        </View>

        <View style={styles.vehicleCard}>
          <View style={styles.vehicleIcon}><Ionicons name="car" size={40} color="#FFFFFF" /></View>
          <Text style={styles.vehicleName}>{currentRepair.vehicle}</Text>
          <Text style={styles.vehicleIssue}>{currentRepair.issue}</Text>
        </View>

        <View style={styles.statusCard}>
          <View style={styles.statusHeader}>
            <Text style={styles.statusLabel}>Statut</Text>
            <View style={[styles.statusBadge, { backgroundColor: statusColor + '20' }]}>
              <Text style={[styles.statusText, { color: statusColor }]}>{getStatusText(currentRepair.status)}</Text>
            </View>
          </View>
          <View style={styles.progressContainer}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressLabel}>Progression</Text>
              <Text style={styles.progressValue}>{currentRepair.progress || 0}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${currentRepair.progress || 0}%`, backgroundColor: progressColor }]} />
            </View>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.cardTitle}>Informations</Text>
          <View style={styles.infoRow}>
            <View style={styles.infoItem}><Ionicons name="person" size={20} color={COLORS.secondary} /><Text style={styles.infoLabel}>Client</Text><Text style={styles.infoValue}>{currentRepair.client || 'Non défini'}</Text></View>
            <View style={styles.infoItem}><Ionicons name="calendar" size={20} color={COLORS.secondary} /><Text style={styles.infoLabel}>Date</Text><Text style={styles.infoValue}>{formatDate(currentRepair.date)}</Text></View>
          </View>
          <View style={styles.infoRow}>
            <View style={styles.infoItem}><Ionicons name="time" size={20} color={COLORS.secondary} /><Text style={styles.infoLabel}>Délai</Text><Text style={styles.infoValue}>{currentRepair.estimatedTime || 'Non défini'}</Text></View>
            <View style={styles.infoItem}><Ionicons name="cash" size={20} color={COLORS.secondary} /><Text style={styles.infoLabel}>Estimation</Text><Text style={styles.infoValue}>{formatCost(currentRepair.estimatedCost)}</Text></View>
          </View>
          <View style={styles.descriptionContainer}>
            <Ionicons name="document-text" size={20} color={COLORS.secondary} />
            <Text style={styles.descriptionLabel}>Description</Text>
            <Text style={styles.descriptionText}>{currentRepair.description || 'Aucune description disponible'}</Text>
          </View>
        </View>

        <View style={styles.garageCard}>
          <Text style={styles.cardTitle}>Garage</Text>
          <View style={styles.garageInfo}>
            <Ionicons name="business" size={24} color={COLORS.secondary} />
            <View style={styles.garageDetails}>
              <Text style={styles.garageName}>{currentRepair.garage || 'Garage Pro'}</Text>
              <Text style={styles.garageAddress}>{currentRepair.garageAddress || '123 Rue Principale, Paris'}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.actionButton} onPress={callGarage}><Ionicons name="call" size={20} color="#FFFFFF" /><Text style={styles.actionButtonText}>Appeler le garage</Text></TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.payButton]} onPress={() => navigation.navigate('Payment', { repair: currentRepair })}>
            <Ionicons name="card" size={20} color="#FFFFFF" /><Text style={styles.actionButtonText}>Payer maintenant</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: COLORS.textSecondary, fontSize: 16, marginTop: 16 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 16 },
  backButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 24, fontWeight: '700', color: COLORS.text, marginLeft: 16 },
  vehicleCard: { backgroundColor: COLORS.primary, marginHorizontal: 16, marginTop: 8, borderRadius: 16, padding: 20, alignItems: 'center' },
  vehicleIcon: { width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  vehicleName: { fontSize: 22, fontWeight: '700', color: COLORS.text, textAlign: 'center' },
  vehicleIssue: { fontSize: 14, color: COLORS.light, marginTop: 4 },
  statusCard: { backgroundColor: COLORS.card, marginHorizontal: 16, marginTop: 16, borderRadius: 12, padding: 16 },
  statusHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  statusLabel: { fontSize: 14, color: COLORS.textSecondary },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  statusText: { fontSize: 14, fontWeight: '600' },
  progressContainer: { marginTop: 8 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  progressLabel: { fontSize: 14, color: COLORS.textSecondary },
  progressValue: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  progressBar: { height: 8, backgroundColor: COLORS.primary, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 4 },
  infoCard: { backgroundColor: COLORS.card, marginHorizontal: 16, marginTop: 16, borderRadius: 12, padding: 16 },
  cardTitle: { fontSize: 18, fontWeight: '600', color: COLORS.text, marginBottom: 16 },
  infoRow: { flexDirection: 'row', marginBottom: 16 },
  infoItem: { flex: 1, alignItems: 'center' },
  infoLabel: { fontSize: 12, color: COLORS.textSecondary, marginTop: 4, marginBottom: 4 },
  infoValue: { fontSize: 14, color: COLORS.text, fontWeight: '500', textAlign: 'center' },
  descriptionContainer: { marginTop: 8, paddingTop: 16, borderTopWidth: 1, borderTopColor: COLORS.primary },
  descriptionLabel: { fontSize: 12, color: COLORS.textSecondary, marginBottom: 8 },
  descriptionText: { fontSize: 14, color: COLORS.text, lineHeight: 20 },
  garageCard: { backgroundColor: COLORS.card, marginHorizontal: 16, marginTop: 16, marginBottom: 32, borderRadius: 12, padding: 16 },
  garageInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  garageDetails: { marginLeft: 12, flex: 1 },
  garageName: { fontSize: 16, fontWeight: '600', color: COLORS.text },
  garageAddress: { fontSize: 14, color: COLORS.textSecondary, marginTop: 4 },
  actionButton: { flexDirection: 'row', backgroundColor: COLORS.primary, borderRadius: 12, padding: 14, alignItems: 'center', justifyContent: 'center', marginTop: 12 },
  actionButtonText: { color: COLORS.text, fontSize: 16, fontWeight: '600', marginLeft: 8 },
  payButton: { backgroundColor: COLORS.success },
  modalOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'center', alignItems: 'center', zIndex: 1000 },
  modalContent: { backgroundColor: COLORS.card, borderRadius: 16, padding: 24, alignItems: 'center', width: '80%', maxWidth: 320 },
  modalIcon: { width: 80, height: 80, borderRadius: 40, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: '600', color: COLORS.text, marginBottom: 8 },
  modalPhone: { fontSize: 24, fontWeight: '700', color: COLORS.secondary, marginBottom: 24 },
  modalCallButton: { backgroundColor: COLORS.success, borderRadius: 12, padding: 14, width: '100%', alignItems: 'center', marginBottom: 12 },
  modalCallButtonText: { color: COLORS.text, fontSize: 16, fontWeight: '600' },
  modalCloseButton: { backgroundColor: COLORS.primary, borderRadius: 12, padding: 14, width: '100%', alignItems: 'center' },
  modalCloseButtonText: { color: COLORS.text, fontSize: 16, fontWeight: '600' },
});
