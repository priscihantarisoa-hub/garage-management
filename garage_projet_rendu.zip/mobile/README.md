# Garage Pro - Application Mobile React Native

## 🚀 Guide de Génération APK

### Prérequis

1. **Node.js** (version 18 ou supérieure)
2. **Expo CLI** : `npm install -g expo-cli`
3. **EAS CLI** : `npm install -g eas-cli`
4. **Compte Expo** : Créer un compte sur [expo.dev](https://expo.dev)

### Installation des dépendances

```bash
cd mobile
npm install
```

### Configuration Firebase

#### 1. Créer un projet Firebase

1. Allez sur [Firebase Console](https://console.firebase.google.com/)
2. Cliquez sur "Ajouter un projet"
3. Suivez les instructions pour créer le projet

#### 2. Activer Firebase Authentication

1. Dans la console Firebase, allez dans **Authentication**
2. Cliquez sur "Commencer"
3. Allez dans l'onglet "Méthode de connexion"
4. Activez "Email/Mot de passe"

#### 3. Activer Cloud Firestore

1. Dans la console Firebase, allez dans **Firestore Database**
2. Cliquez sur "Créer une base de données"
3. Choisissez un emplacement (ex: europe-west1)
4. Démarrez en mode test pour le développement

#### 4. Configuration Android

1. Dans Firebase Console, ajoutez une application Android
2. Entrez le nom du package: `com.garage.pro`
3. Téléchargez le fichier `google-services.json`
4. Placez-le dans le dossier `mobile/google-services.json`

#### 5. Configuration de firebaseConfig.js

Ouvrez le fichier `mobile/firebaseConfig.js` et remplacez les valeurs:

```javascript
const firebaseConfig = {
  apiKey: "VOTRE_API_KEY",
  authDomain: "VOTRE_PROJECT_ID.firebaseapp.com",
  projectId: "VOTRE_PROJECT_ID",
  storageBucket: "VOTRE_PROJECT_ID.appspot.com",
  messagingSenderId: "VOTRE_SENDER_ID",
  appId: "VOTRE_APP_ID"
};
```

### Génération de l'APK

#### Méthode 1 : Build local avec EAS (Recommandé)

```bash
# Se connecter à Expo
eas login

# Configurer le projet (une seule fois)
eas build:configure

# Build APK pour prévisualisation
eas build -p android --profile preview

# Build APK pour production
eas build -p android --profile production
```

#### Méthode 2 : Build local avec expo-build-properties

Ajoutez dans `app.json`:
```json
{
  "expo": {
    "plugins": [
      [
        "expo-build-properties",
        {
          "android": {
            "compileSdkVersion": 34,
            "targetSdkVersion": 34,
            "buildToolsVersion": "34.0.0"
          }
        }
      ]
    ]
  }
}
```

Puis lancez:
```bash
npx expo prebuild
npx expo export:embedded
eas build -p android
```

#### Méthode 3 : Build en ligne (Expo Cloud)

1. Allez sur [expo.dev](https://expo.dev)
2. Connectez-vous avec votre compte
3. Allez dans "Builds"
4. Cliquez sur "Create Build"
5. Sélectionnez "Android" et "APK"
6. Suivez les instructions

### Installation de l'APK

1. Récupérez le fichier `.apk` généré
2. Transférez-le sur votre appareil Android
3. Activez "Sources inconnues" dans les paramètres Android
4. Installez l'APK

## 📱 Fonctionnalités

### Authentification
- Inscription avec email/mot de passe (Firebase Auth)
- Connexion avec email/mot de passe
- Fallback vers API Laravel si Firebase non configuré

### Réparations
- Liste des véhicules en réparation
- Statut en temps réel (en attente, en cours, terminé)
- Barre de progression des réparations
- Calcul automatique du prix estimé

### Notifications
- Firebase Cloud Messaging pour les notifications push
- Notifications locales avec Expo
- Canaux de notification Android
- Notifications en temps réel via Firestore

### Paiement
- Intégration Stripe (code prêt à activé)
- Simulation de paiement pour le développement

## 🏗️ Structure du projet

```
mobile/
├── App.js                    # Navigation principale
├── firebaseConfig.js         # Configuration Firebase
├── NotificationService.js    # Service de notifications
├── eas.json                 # Configuration EAS Build
├── app.json                 # Configuration Expo
├── google-services.json     # Firebase Android (à ajouter)
├── LoginScreen.js           # Écran de connexion
├── RegisterScreen.js        # Écran d'inscription
├── RepairsScreen.js         # Liste des réparations
├── ReportScreen.js          # Nouvelle demande de réparation
├── RepairDetailScreen.js    # Détail d'une réparation
├── PaymentScreen.js          # Écran de paiement
├── NotificationTestScreen.js # Test des notifications
├── ProfileScreen.js         # Profil utilisateur
├── package.json             # Dépendances
└── README.md               # Ce fichier
```

## 🔧 Types de réparations

- Freins (80€)
- Vidange (50€)
- Filtre (30€)
- Batterie (70€)
- Amortisseurs (120€)
- Embrayage (200€)
- Pneus (60€ par pneu)
- Système de refroidissement (100€)

## 📊 Notes importantes

- Le garage peut accueillir 3 voitures en même temps
- Les notifications sont envoyées quand les réparations sont prêtes
- Le mode hors ligne utilise des données de démonstration
- Pour la production, configurez les règles Firestore et les règles de sécurité

## 🐛 Dépannage

### Erreur "google-services.json non trouvé"
- Assurez-vous d'avoir téléchargé le fichier depuis Firebase Console
- Placez-le à la racine du dossier `mobile`

### Erreur de build EAS
- Vérifiez que vous êtes connecté avec `eas login`
- Vérifiez la configuration dans `app.json` et `eas.json`

### Notifications non reçues
- Vérifiez les permissions Android
- Assurez-vous que FCM est correctement configuré dans Firebase
