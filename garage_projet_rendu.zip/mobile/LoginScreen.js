import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
  Dimensions,
  ScrollView,
  ImageBackground,
  Animated
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AuthContext } from './App';
import { Ionicons } from '@expo/vector-icons';
import { login as apiLogin, setAuthToken, TEST_MODE } from './api';

const { width } = Dimensions.get('window');

// Palette de couleurs bleue professionnelle
const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  tertiary: '#A7EBF2',
  background: '#F5F5F7',
  white: '#FFFFFF',
  text: '#1C1C1E',
  textSecondary: '#8E8E93',
  border: '#E5E5EA',
  error: '#FF3B30',
  overlay: 'rgba(0,0,0,0.4)',
};

export default function LoginScreen({ navigation, route }) {
  const { refreshAuthState } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Animation values
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(50));

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (route?.params?.email) {
      setEmail(route.params.email);
    }
  }, [route?.params?.email]);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Erreur', 'Veuillez remplir tous les champs');
      return;
    }

    setLoading(true);

    const timeout = setTimeout(() => {
      setLoading(false);
      Alert.alert('Erreur', 'La connexion est trop lente.');
    }, 10000);

    try {
      console.log('🔐 Connexion à l\'API...');
      
      const response = await apiLogin(email, password);
      
      clearTimeout(timeout);
      setLoading(false);
      
      if (response.success) {
        // Sauvegarder le token et l'utilisateur
        await AsyncStorage.setItem('token', response.data.token);
        await AsyncStorage.setItem('user', JSON.stringify(response.data.user));
        
        // Définir le token pour les futures requêtes
        setAuthToken(response.data.token);
        
        Alert.alert('Succès', `Bienvenue ${response.data.user.name}!`);
        await refreshAuthState();
      } else {
        Alert.alert('Échec', response.message || 'Email ou mot de passe incorrect.');
      }
        
    } catch (error) {
      clearTimeout(timeout);
      setLoading(false);
      console.error('❌ Erreur:', error);
      
      if (TEST_MODE) {
        // Fallback en mode test
        const userData = {
          id: 'test-user-' + Date.now(),
          email: email,
          name: email.split('@')[0]
        };
        await AsyncStorage.setItem('user', JSON.stringify(userData));
        Alert.alert('Mode Test', 'Connexion simulée réussie');
        await refreshAuthState();
      } else {
        Alert.alert('Échec', 'Impossible de se connecter au serveur.');
      }
    }
  };

  const handleRegister = () => {
    navigation.navigate('Register');
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        
          {/* Background Image */}
          <ImageBackground 
            source={{ uri: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&h=600&fit=crop' }}
            style={styles.backgroundImage}
          >
            <View style={styles.overlay}>
              {/* Logo & Title */}
              <Animated.View 
                style={[
                  styles.headerContent,
                  {
                    opacity: fadeAnim,
                    transform: [{ translateY: slideAnim }],
                  },
                ]}
              >
                <View style={styles.logoContainer}>
                  <View style={styles.logoCircle}>
                    <Ionicons name="car-sport" size={50} color="white" />
                  </View>
                  <Text style={styles.logoText}>GARAGE PRO</Text>
                </View>
                <Text style={styles.subtitle}>Gestion Professionnelle</Text>
              </Animated.View>
            </View>
          </ImageBackground>

          {/* Form Card */}
          <View style={styles.formCard}>
            <Text style={styles.welcomeText}> Bon retour parmi nous!{'\n'}Identifiez-vous </Text>

            <View style={styles.inputContainer}>
              <Ionicons name="mail-outline" size={20} color={COLORS.textSecondary} />
              <TextInput
                style={styles.input}
                placeholder="Adresse email"
                placeholderTextColor={COLORS.textSecondary}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputContainer}>
              <Ionicons name="lock-closed-outline" size={20} color={COLORS.textSecondary} />
              <TextInput
                style={styles.input}
                placeholder="Mot de passe"
                placeholderTextColor={COLORS.textSecondary}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
              />
            </View>

            <TouchableOpacity 
              style={styles.forgotPassword}
              onPress={() => Alert.alert('Info', 'Fonctionnalité à venir')}
            >
              <Text style={styles.forgotPasswordText}>Mot de passe oublié ?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.loginButton} 
              onPress={handleLogin}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="white" />
              ) : (
                <>
                  <Ionicons name="log-in-outline" size={20} color="white" />
                  <Text style={styles.loginButtonText}> Se connecter </Text>
                </>
              )}
            </TouchableOpacity>

            <View style={styles.divider}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>ou</Text>
              <View style={styles.dividerLine} />
            </View>

            <TouchableOpacity 
              style={styles.registerButton} 
              onPress={handleRegister}
            >
              <Text style={styles.registerButtonText}>Créer un compte</Text>
            </TouchableOpacity>
            
            {/* Test Mode Banner */}
            {TEST_MODE && (
              <View style={styles.testBanner}>
                <Ionicons name="warning-outline" size={16} color="#ffa500" />
                <Text style={styles.testBannerText}>Mode Test Activé</Text>
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  keyboardView: {
    flex: 1,
  },
  backgroundImage: {
    height: 280,
    justifyContent: 'center',
  },
  overlay: {
    flex: 1,
    backgroundColor: COLORS.overlay,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerContent: {
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  logoCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
    letterSpacing: 3,
  },
  subtitle: {
    fontSize: 16,
    color: COLORS.tertiary,
    marginTop: 5,
  },
  formCard: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    marginTop: -30,
    paddingHorizontal: 24,
    paddingTop: 30,
    paddingBottom: 40,
    minHeight: 500,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 25,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: 12,
    paddingHorizontal: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  input: {
    flex: 1,
    paddingVertical: 15,
    paddingHorizontal: 10,
    fontSize: 16,
    color: COLORS.text,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: 20,
  },
  forgotPasswordText: {
    color: COLORS.primary,
    fontSize: 14,
  },
  loginButton: {
    flexDirection: 'row',
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    paddingVertical: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  loginButtonText: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 25,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: COLORS.border,
  },
  dividerText: {
    marginHorizontal: 15,
    color: COLORS.textSecondary,
    fontSize: 14,
  },
  registerButton: {
    backgroundColor: 'transparent',
    borderRadius: 12,
    paddingVertical: 16,
    borderWidth: 2,
    borderColor: COLORS.primary,
  },
  registerButtonText: {
    color: COLORS.primary,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  testBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    padding: 10,
    backgroundColor: '#fff3cd',
    borderRadius: 8,
  },
  testBannerText: {
    marginLeft: 8,
    color: '#856404',
    fontSize: 12,
  },
});
