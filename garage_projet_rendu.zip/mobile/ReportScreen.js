import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Switch,
  Alert,
  ActivityIndicator
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const REPAIR_TYPES = [
  { id: 1, name: 'Freins', color: '#E50914', basePrice: 80 },
  { id: 2, name: 'Moteur', color: '#E87C03', basePrice: 120 },
  { id: 3, name: 'Pneus', color: '#46d369', basePrice: 60 },
  { id: 4, name: 'Electrique', color: '#0071EB', basePrice: 90 },
  { id: 5, name: 'Carrosserie', color: '#B81D24', basePrice: 150 },
  { id: 6, name: 'Vidange', color: '#FF8717', basePrice: 50 },
  { id: 7, name: 'Batterie', color: '#FFD700', basePrice: 70 },
  { id: 8, name: 'Amortisseurs', color: '#8B4513', basePrice: 200 },
];

export default function ReportScreen({ navigation }) {
  const [vehicle, setVehicle] = useState('');
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [description, setDescription] = useState('');
  const [urgent, setUrgent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submittedData, setSubmittedData] = useState(null);

  const toggleType = (id) => {
    if (selectedTypes.includes(id)) {
      setSelectedTypes(selectedTypes.filter(typeId => typeId !== id));
    } else {
      setSelectedTypes([...selectedTypes, id]);
    }
  };

  const calculatePrice = () => {
    let total = 0;
    selectedTypes.forEach(typeId => {
      const type = REPAIR_TYPES.find(t => t.id === typeId);
      if (type) total += type.basePrice;
    });
    if (urgent) total += 30;
    return total;
  };

  const generatePlate = () => {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const randomLetter = () => letters[Math.floor(Math.random() * letters.length)];
    const randomNumber = () => numbers[Math.floor(Math.random() * numbers.length)];
    return randomLetter() + randomLetter() + '-' + randomNumber() + randomNumber() + randomNumber() + '-' + randomLetter() + randomLetter();
  };

  const handleSubmit = async () => {
    if (!vehicle || selectedTypes.length === 0) {
      Alert.alert('Erreur', 'Veuillez remplir au moins le vehicule et selectionner un type de panne');
      return;
    }

    setLoading(true);

    await new Promise(resolve => setTimeout(resolve, 2000));

    const plate = generatePlate();
    const price = calculatePrice();

    try {
      const repairId = Date.now().toString();
      
      const newRepair = {
        id: repairId,
        vehicle: vehicle,
        plate: plate,
        services: selectedTypes.map(id => REPAIR_TYPES.find(t => t.id === id).name),
        description: description || 'Aucune description fournie',
        status: 'pending',
        progress: 0,
        price: price,
        createdAt: new Date().toISOString(),
        urgent: urgent
      };

      const existingRepairs = await AsyncStorage.getItem('repairs');
      const repairs = existingRepairs ? JSON.parse(existingRepairs) : [];
      repairs.unshift(newRepair);
      await AsyncStorage.setItem('repairs', JSON.stringify(repairs));

      setLoading(false);
      
      setSubmittedData({
        vehicle,
        plate,
        price,
        repairId: repairId.slice(-8).toUpperCase()
      });
      setSubmitted(true);

    } catch (error) {
      setLoading(false);
      Alert.alert('Erreur', 'Une erreur est survenue. Veuillez reessayer.');
    }
  };

  const handleAddNew = () => {
    setSubmitted(false);
    setSubmittedData(null);
    setVehicle('');
    setSelectedTypes([]);
    setDescription('');
    setUrgent(false);
  };

  const estimatedPrice = calculatePrice();

  if (submitted && submittedData) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={true}>
          <View style={styles.successContainer}>
            <View style={styles.successIcon}>
              <Text style={styles.successIconText}>OK</Text>
            </View>
            <Text style={styles.successTitle}>Demande Envoyee!</Text>
            <Text style={styles.successSubtitle}>Votre reparation a ete enregistree</Text>
            
            <View style={styles.successCard}>
              <View style={styles.successRow}>
                <Text style={styles.successLabel}>Vehicule:</Text>
                <Text style={styles.successValue}>{submittedData.vehicle}</Text>
              </View>
              <View style={styles.successRow}>
                <Text style={styles.successLabel}>Plaque:</Text>
                <Text style={styles.successValue}>{submittedData.plate}</Text>
              </View>
              <View style={styles.successRow}>
                <Text style={styles.successLabel}>Prix:</Text>
                <Text style={[styles.successValue, { color: '#46d369' }]}>{submittedData.price}euro</Text>
              </View>
              <View style={styles.successRow}>
                <Text style={styles.successLabel}>Reference:</Text>
                <Text style={styles.successValue}>{submittedData.repairId}</Text>
              </View>
            </View>

            <Text style={styles.successMessage}>
              Un mecanicien vous contactera sous 2h pour confirmer le rendez-vous.
            </Text>

            <TouchableOpacity 
              style={styles.successButton}
              onPress={() => navigation.navigate('Repairs')}
            >
              <Text style={styles.successButtonText}>VOIR MES REPARATIONS</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.secondaryButton}
              onPress={handleAddNew}
            >
              <Text style={styles.secondaryButtonText}>AJOUTER UNE AUTRE REPARATION</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.homeButton}
              onPress={() => navigation.reset({ index: 0, routes: [{ name: 'Repairs' }] })}
            >
              <Text style={styles.homeButtonText}>RETOUR A L'ACCUEIL</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={true}>
        <View style={styles.header}>
          <Text style={styles.title}>Deposer une panne</Text>
          <Text style={styles.subtitle}>Remplissez le formulaire ci-dessous</Text>
          
          {selectedTypes.length > 0 && (
            <View style={styles.pricePreview}>
              <Text style={styles.pricePreviewText}>
                Prix estime: <Text style={styles.priceValue}>{estimatedPrice}euro</Text>
                {urgent && <Text style={styles.urgentBadge}> +30euro (urgence)</Text>}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.formCard}>
          <Text style={styles.label}>VEHICULE *</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex: Peugeot 208, Renault Clio..."
            placeholderTextColor="#666"
            value={vehicle}
            onChangeText={setVehicle}
            editable={!loading}
          />

          <Text style={styles.label}>TYPE(S) DE PANNE *</Text>
          <View style={styles.typesGrid}>
            {REPAIR_TYPES.map(type => (
              <TouchableOpacity
                key={type.id}
                style={[
                  styles.typeButton,
                  { borderColor: selectedTypes.includes(type.id) ? type.color : '#404040' },
                  selectedTypes.includes(type.id) && { backgroundColor: type.color + '33' }
                ]}
                onPress={() => toggleType(type.id)}
                disabled={loading}
              >
                <Text style={[
                  styles.typeButtonText,
                  selectedTypes.includes(type.id) && { color: type.color }
                ]}>
                  {type.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>DESCRIPTION DETAILLEE</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Decrivez les symptomes, le bruit, le moment ou c'est arrive..."
            placeholderTextColor="#666"
            value={description}
            onChangeText={setDescription}
            multiline
            numberOfLines={4}
            editable={!loading}
          />

          <View style={styles.urgentRow}>
            <Text style={styles.urgentLabel}>Urgence</Text>
            <Text style={styles.urgentSubtext}>Priorite maximum (+30euro)</Text>
            <Switch
              value={urgent}
              onValueChange={setUrgent}
              trackColor={{ false: '#404040', true: '#E50914' }}
              thumbColor="white"
            />
          </View>

          <TouchableOpacity 
            style={styles.photosButton}
            onPress={() => Alert.alert('Photos', 'Fonctionnalite en developpement')}
            disabled={loading}
          >
            <Text style={styles.photosButtonText}>Ajouter des photos (optionnel)</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>Comment ca marche?</Text>
          <Text style={styles.infoText}>- Selectionnez le type de panne (prix indicatif)</Text>
          <Text style={styles.infoText}>- Remplissez la description pour un diagnostic precis</Text>
          <Text style={styles.infoText}>- Option "urgence" pour une prise en charge prioritaire</Text>
          <Text style={styles.infoText}>- Un mecanicien vous contactera pour confirmation</Text>
          <Text style={styles.infoText}>- Suivez l'avancement dans l'application</Text>
        </View>

        {selectedTypes.length > 0 && (
          <View style={styles.priceBreakdown}>
            <Text style={styles.breakdownTitle}>Detail du prix estime:</Text>
            {selectedTypes.map(typeId => {
              const type = REPAIR_TYPES.find(t => t.id === typeId);
              return (
                <View key={typeId} style={styles.breakdownRow}>
                  <Text style={styles.breakdownItem}>- {type.name}: {type.basePrice}euro</Text>
                </View>
              );
            })}
            {urgent && (
              <View style={styles.breakdownRow}>
                <Text style={styles.breakdownItem}>- Majoration urgence: +30euro</Text>
              </View>
            )}
            <View style={[styles.breakdownRow, styles.totalRow]}>
              <Text style={styles.totalLabel}>TOTAL: {estimatedPrice}euro</Text>
            </View>
          </View>
        )}

        <TouchableOpacity 
          style={[
            styles.submitButton,
            (!vehicle || selectedTypes.length === 0 || loading) && styles.submitButtonDisabled
          ]}
          onPress={handleSubmit}
          disabled={!vehicle || selectedTypes.length === 0 || loading}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.submitButtonText}>VALIDER LA DEMANDE</Text>
          )}
        </TouchableOpacity>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#141414',
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#B3B3B3',
    marginBottom: 15,
  },
  pricePreview: {
    backgroundColor: '#181818',
    padding: 12,
    borderRadius: 8,
    marginTop: 10,
  },
  pricePreviewText: {
    fontSize: 14,
    color: '#B3B3B3',
  },
  priceValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#46d369',
  },
  urgentBadge: {
    color: '#E50914',
    fontWeight: '600',
  },
  formCard: {
    backgroundColor: '#181818',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 20,
    borderWidth: 1,
    borderColor: '#2D2D2D',
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: '#B3B3B3',
    marginBottom: 8,
    marginTop: 16,
    letterSpacing: 1,
  },
  input: {
    backgroundColor: '#2D2D2D',
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    color: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#404040',
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  typesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  typeButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#404040',
    backgroundColor: 'transparent',
  },
  typeButtonText: {
    fontSize: 12,
    color: '#B3B3B3',
    fontWeight: '600',
  },
  urgentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#2D2D2D',
  },
  urgentLabel: {
    flex: 1,
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  urgentSubtext: {
    fontSize: 12,
    color: '#B3B3B3',
    marginRight: 10,
  },
  photosButton: {
    marginTop: 20,
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#404040',
    borderStyle: 'dashed',
    alignItems: 'center',
  },
  photosButtonText: {
    color: '#B3B3B3',
    fontSize: 14,
  },
  infoSection: {
    padding: 20,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  infoText: {
    fontSize: 13,
    color: '#B3B3B3',
    marginBottom: 5,
    lineHeight: 18,
  },
  priceBreakdown: {
    backgroundColor: '#181818',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#2D2D2D',
  },
  breakdownTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  breakdownRow: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  breakdownItem: {
    fontSize: 13,
    color: '#B3B3B3',
  },
  totalRow: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#2D2D2D',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: '#46d369',
  },
  submitButton: {
    backgroundColor: '#E50914',
    borderRadius: 8,
    padding: 18,
    alignItems: 'center',
    marginHorizontal: 20,
    marginBottom: 20,
  },
  submitButtonDisabled: {
    backgroundColor: '#B81D24',
    opacity: 0.6,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  bottomSpacer: {
    height: 40,
  },
  successContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#46d369',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  successIconText: {
    fontSize: 40,
    color: 'white',
  },
  successTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  successSubtitle: {
    fontSize: 16,
    color: '#B3B3B3',
    marginBottom: 30,
  },
  successCard: {
    backgroundColor: '#181818',
    borderRadius: 12,
    padding: 20,
    width: '100%',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#2D2D2D',
  },
  successRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  successLabel: {
    fontSize: 14,
    color: '#B3B3B3',
  },
  successValue: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  successMessage: {
    fontSize: 14,
    color: '#B3B3B3',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 20,
  },
  successButton: {
    backgroundColor: '#46d369',
    borderRadius: 8,
    padding: 18,
    alignItems: 'center',
    width: '100%',
    marginBottom: 12,
  },
  successButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#404040',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    width: '100%',
  },
  secondaryButtonText: {
    color: '#B3B3B3',
    fontSize: 14,
    fontWeight: '600',
  },
  homeButton: {
    marginTop: 10,
    padding: 16,
    alignItems: 'center',
    width: '100%',
  },
  homeButtonText: {
    color: '#666',
    fontSize: 14,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
});
