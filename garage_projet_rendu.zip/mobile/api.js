// Configuration de l'API Laravel
const API_BASE_URL = 'http://localhost:8000/api';

// Mode de test - mettre false pour utiliser la vraie API
export const TEST_MODE = false;

// Token d'authentification
let authToken = null;

export const setAuthToken = (token) => {
  authToken = token;
};

export const getAuthHeader = () => {
  if (authToken) {
    return { 'Authorization': `Bearer ${authToken}` };
  }
  return {};
};

// ==================== AUTH ====================

export const login = async (email, password) => {
  if (TEST_MODE) {
    // Simulation pour le test
    await new Promise(resolve => setTimeout(resolve, 1000));
    return {
      success: true,
      data: {
        user: { id: 1, name: email.split('@')[0], email },
        token: 'test-token-' + Date.now(),
        token_type: 'Bearer'
      }
    };
  }

  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password }),
  });

  const data = await response.json();
  return data;
};

export const register = async (userData) => {
  if (TEST_MODE) {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return {
      success: true,
      data: {
        user: { id: 1, ...userData },
        token: 'test-token-' + Date.now(),
        token_type: 'Bearer'
      }
    };
  }

  const response = await fetch(`${API_BASE_URL}/auth/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(userData),
  });

  const data = await response.json();
  return data;
};

export const getProfile = async () => {
  const response = await fetch(`${API_BASE_URL}/auth/profile`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const logout = async () => {
  if (TEST_MODE) return { success: true };

  const response = await fetch(`${API_BASE_URL}/auth/logout`, {
    method: 'POST',
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

// ==================== INTERVENTIONS ====================

export const getInterventions = async () => {
  const response = await fetch(`${API_BASE_URL}/interventions`);
  const data = await response.json();
  return data;
};

export const getInterventionTypes = async () => {
  const response = await fetch(`${API_BASE_URL}/interventions/types`);
  const data = await response.json();
  return data;
};

// ==================== CLIENTS ====================

export const getClients = async (search = '') => {
  const url = search 
    ? `${API_BASE_URL}/clients?search=${encodeURIComponent(search)}`
    : `${API_BASE_URL}/clients`;
  
  const response = await fetch(url, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const getClientRepairs = async (clientId) => {
  const response = await fetch(`${API_BASE_URL}/clients/${clientId}/repairs`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

// ==================== REPAIRS ====================

export const getRepairs = async (status = null) => {
  let url = `${API_BASE_URL}/repairs`;
  if (status) {
    url += `?statut=${status}`;
  }

  const response = await fetch(url, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const getActiveRepairs = async () => {
  const response = await fetch(`${API_BASE_URL}/repairs/active`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const getCompletedRepairs = async () => {
  const response = await fetch(`${API_BASE_URL}/repairs/completed`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const createRepair = async (repairData) => {
  const response = await fetch(`${API_BASE_URL}/repairs`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeader(),
    },
    body: JSON.stringify(repairData),
  });

  const data = await response.json();
  return data;
};

export const updateRepairStatus = async (repairId, status) => {
  const response = await fetch(`${API_BASE_URL}/repairs/${repairId}/status`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeader(),
    },
    body: JSON.stringify({ statut: status }),
  });

  const data = await response.json();
  return data;
};

export const getRepairDetails = async (repairId) => {
  const response = await fetch(`${API_BASE_URL}/repairs/${repairId}`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const getStats = async () => {
  const response = await fetch(`${API_BASE_URL}/stats`);
  const data = await response.json();
  return data;
};

// ==================== PAYMENTS ====================

export const payRepair = async (repairId, methode) => {
  const response = await fetch(`${API_BASE_URL}/payments/pay/${repairId}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeader(),
    },
    body: JSON.stringify({ methode }),
  });

  const data = await response.json();
  return data;
};

export const getPayments = async () => {
  const response = await fetch(`${API_BASE_URL}/payments`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};

export const getPaymentStats = async () => {
  const response = await fetch(`${API_BASE_URL}/payments/stats`, {
    headers: {
      ...getAuthHeader(),
    },
  });

  const data = await response.json();
  return data;
};
