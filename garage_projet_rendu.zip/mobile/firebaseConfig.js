import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
  serverTimestamp
} from 'firebase/firestore';
import { 
  getMessaging, 
  getToken, 
  onMessage 
} from 'firebase/messaging';

// Configuration Firebase - Configuration de Garage Pro
const firebaseConfig = {
  apiKey: "AIzaSyBEGdTiWD5b3lGBLq02zo6_UTLFEHuSY0E",
  authDomain: "garage-pro-c35c6.firebaseapp.com",
  projectId: "garage-pro-c35c6",
  storageBucket: "garage-pro-c35c6.firebasestorage.app",
  messagingSenderId: "432871738486",
  appId: "1:432871738486:web:a95c44343feb199f292357",
  measurementId: "G-1YC5YNB2F4"
};

// Initialiser Firebase
let app;
let auth;
let db;
let messaging;

try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  
  // Vérifier si messaging est supported
  if (typeof messaging !== 'undefined') {
    messaging = getMessaging(app);
  }
} catch (error) {
  console.error('Erreur d\'initialisation Firebase:', error);
}

// Fonctions d'authentification
export const loginWithEmail = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
    
    if (userDoc.exists()) {
      return { 
        success: true, 
        user: { 
          id: userCredential.user.uid, 
          email: userCredential.user.email,
          ...userDoc.data() 
        } 
      };
    }
    
    return { success: true, user: userCredential.user };
  } catch (error) {
    console.error('Erreur de connexion:', error);
    return { success: false, error: error.message };
  }
};

export const registerWithEmail = async (email, password, name) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    
    // Créer le document utilisateur dans Firestore
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      name: name,
      email: email,
      createdAt: serverTimestamp(),
      role: 'client'
    });
    
    return { 
      success: true, 
      user: { 
        id: userCredential.user.uid, 
        email: userCredential.user.email,
        name: name 
      } 
    };
  } catch (error) {
    console.error('Erreur d\'inscription:', error);
    return { success: false, error: error.message };
  }
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    console.error('Erreur de déconnexion:', error);
    return { success: false, error: error.message };
  }
};

export const resetPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return { success: true };
  } catch (error) {
    console.error('Erreur de réinitialisation:', error);
    return { success: false, error: error.message };
  }
};

// Fonctions Firestore pour les réparations
export const getUserRepairs = async (userId) => {
  try {
    const repairsRef = collection(db, 'repairs');
    const q = query(
      repairsRef, 
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const repairs = [];
    
    querySnapshot.forEach((doc) => {
      repairs.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    return { success: true, repairs };
  } catch (error) {
    console.error('Erreur lors de la récupération des réparations:', error);
    return { success: false, error: error.message, repairs: [] };
  }
};

export const createRepairRequest = async (userId, vehicleData, issues) => {
  try {
    const repairsRef = collection(db, 'repairs');
    const newRepair = {
      userId: userId,
      vehicle: vehicleData,
      issues: issues,
      status: 'pending',
      createdAt: serverTimestamp(),
      garageSlots: {
        slot1: null,
        slot2: null
      }
    };
    
    const docRef = await addDoc(repairsRef, newRepair);
    return { success: true, repairId: docRef.id };
  } catch (error) {
    console.error('Erreur lors de la création de la demande:', error);
    return { success: false, error: error.message };
  }
};

export const updateRepairStatus = async (repairId, status, additionalData = {}) => {
  try {
    const repairRef = doc(db, 'repairs', repairId);
    await updateDoc(repairRef, {
      status: status,
      ...additionalData,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error('Erreur lors de la mise à jour du statut:', error);
    return { success: false, error: error.message };
  }
};

// Fonctions de notification
export const requestNotificationPermission = async () => {
  try {
    if (!messaging) {
      console.log('Messaging non supporté sur cette plateforme');
      return null;
    }
    
    const permission = await messaging.requestPermission();
    
    if (permission === messaging.AuthorizationStatus.AUTHORIZED || 
        permission === messaging.AuthorizationStatus.PROVISIONAL) {
      const token = await getToken(messaging);
      return token;
    }
    
    return null;
  } catch (error) {
    console.error('Erreur lors de la demande de permission:', error);
    return null;
  }
};

export const subscribeToNotifications = (callback) => {
  if (!messaging) {
    console.log('Messaging non supporté');
    return () => {};
  }
  
  const unsubscribe = onMessage(messaging, (payload) => {
    console.log('Message reçu:', payload);
    callback(payload);
  });
  
  return unsubscribe;
};

export { app, auth, db, messaging };
