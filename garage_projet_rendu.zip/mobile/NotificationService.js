import { useEffect, useState, useCallback } from 'react';
import { Platform } from 'react-native';
import { 
  getExpoPushTokenAsync, 
  getDevicePushTokenAsync 
} from 'expo-notifications';
import { 
  requestNotificationPermission, 
  subscribeToNotifications 
} from './firebaseConfig';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'http://localhost:8000/api';

export const useNotifications = () => {
  const [expoToken, setExpoToken] = useState(null);
  const [fcmToken, setFcmToken] = useState(null);
  const [notification, setNotification] = useState(null);
  const [isReady, setIsReady] = useState(false);

  // Initialiser les notifications
  const initializeNotifications = useCallback(async () => {
    try {
      // 1. Essayer d'obtenir le token FCM (Firebase)
      const fcmTokenResult = await requestNotificationPermission();
      if (fcmTokenResult) {
        setFcmToken(fcmTokenResult);
        console.log('FCM Token:', fcmTokenResult);
        
        // Stocker le token
        await AsyncStorage.setItem('fcmToken', fcmTokenResult);
        
        // Envoyer le token au serveur Laravel
        await registerTokenOnServer(fcmTokenResult, 'fcm');
      }
    } catch (error) {
      console.log('FCM non disponible:', error);
    }

    try {
      // 2. Fallback vers Expo Push Token
      if (!fcmToken) {
        const token = await getExpoPushTokenAsync({
          projectId: 'YOUR_EXPO_PROJECT_ID' // Remplacez par votre ID de projet Expo
        });
        
        if (token) {
          setExpoToken(token.data);
          console.log('Expo Token:', token.data);
          
          // Stocker le token
          await AsyncStorage.setItem('expoToken', token.data);
          
          // Envoyer le token au serveur Laravel
          await registerTokenOnServer(token.data, 'expo');
        }
      }
    } catch (error) {
      console.log('Expo Push Token non disponible:', error);
    }

    setIsReady(true);
  }, []);

  // S'abettre aux notifications
  const subscribeToRealtimeNotifications = useCallback(() => {
    if (!fcmToken) return () => {};

    const unsubscribe = subscribeToNotifications((payload) => {
      console.log('Notification reçue:', payload);
      
      const newNotification = {
        title: payload.notification?.title || 'Garage Pro',
        body: payload.notification?.body || 'Nouvelle notification',
        data: payload.data || {},
      };
      
      setNotification(newNotification);
      
      // Vous pouvez ajouter une logique supplémentaire ici
      // comme jouer un son, vibrer, etc.
    });

    return unsubscribe;
  }, [fcmToken]);

  // Enregistrer le token sur le serveur
  const registerTokenOnServer = async (token, type) => {
    try {
      const userData = await AsyncStorage.getItem('user');
      const user = userData ? JSON.parse(userData) : null;
      
      if (!user) return;

      await fetch(`${API_URL}/register-push-token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          token: token,
          type: type,
          user_id: user.id
        })
      });
      
      console.log('Token enregistré sur le serveur');
    } catch (error) {
      console.error('Erreur lors de l\'enregistrement du token:', error);
    }
  };

  // Effacer les notifications
  const clearNotifications = useCallback(() => {
    setNotification(null);
  }, []);

  return {
    expoToken,
    fcmToken,
    notification,
    isReady,
    initializeNotifications,
    subscribeToRealtimeNotifications,
    clearNotifications
  };
};

// Fonction pour envoyer une notification via le serveur Laravel
export const sendNotification = async (userId, title, body, data = {}) => {
  try {
    const response = await fetch(`${API_URL}/send-notification`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        user_id: userId,
        title: title,
        body: body,
        data: data
      })
    });

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Erreur lors de l\'envoi de la notification:', error);
    return { success: false, error: error.message };
  }
};

// Fonction pour programmer une notification locale
export const scheduleLocalNotification = async (title, body, delayMs = 5000) => {
  // Note: Cette fonctionnalité nécessite expo-notifications
  // Vous pouvez utiliser Notifications.scheduleNotificationAsync() ici
  
  console.log(`Notification programmée: "${title}" dans ${delayMs}ms`);
  
  return { success: true, message: 'Notification programmée' };
};
