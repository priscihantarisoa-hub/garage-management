import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
  Modal,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';

const API_URL = 'http://localhost:8000/api';

// Taux de conversion EUR -> MGA
const EUR_TO_MGA = 4500;

// Palette de couleurs bleue
const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  tertiary: '#A7EBF2',
  background: '#011C40',
  card: '#023859',
  text: '#FFFFFF',
  textSecondary: '#B3B3B3',
  success: '#46d369',
  warning: '#ffa500',
  error: '#E50914',
};

const PaymentScreen = ({ route, navigation }) => {
  const { repair } = route?.params || {};
  const [amount, setAmount] = useState('');
  const [phone, setPhone] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [paymentResult, setPaymentResult] = useState(null);

  // Convertir EUR en MGA et remplir automatiquement le montant
  useEffect(() => {
    if (repair?.estimatedCost) {
      const costInEur = parseFloat(repair.estimatedCost);
      const costInMga = Math.round(costInEur * EUR_TO_MGA);
      setAmount(costInMga.toString());
    }
  }, [repair]);

  const paymentMethods = [
    {
      id: 'airtel',
      name: 'Airtel Money',
      icon: 'phone-portrait',
      color: '#E31837',
      description: 'Paiement via Airtel Money'
    },
    {
      id: 'mvola',
      name: 'Mvola',
      icon: 'wallet',
      color: '#00A651',
      description: 'Paiement via Mvola'
    },
    {
      id: 'orange',
      name: 'Orange Money',
      icon: 'call',
      color: '#FF6600',
      description: 'Paiement via Orange Money'
    },
    {
      id: 'card',
      name: 'Carte Bancaire',
      icon: 'card',
      color: '#1E3A5F',
      description: 'Visa, Mastercard, etc.'
    }
  ];

  const formatAmount = (value) => {
    const numericValue = value.replace(/[^0-9]/g, '');
    return numericValue;
  };

  const formatExpiryDate = (value) => {
    let formatted = value.replace(/[^0-9]/g, '');
    if (formatted.length >= 2) {
      formatted = formatted.substring(0, 2) + '/' + formatted.substring(2, 4);
    }
    return formatted;
  };

  const formatCardNumber = (value) => {
    const formatted = value.replace(/[^0-9]/g, '');
    let result = '';
    for (let i = 0; i < formatted.length && i < 16; i += 4) {
      if (i > 0) result += ' ';
      result += formatted.substring(i, Math.min(i + 4, formatted.length));
    }
    return result;
  };

  const validatePhone = (phoneNumber) => {
    const phoneRegex = /^(\+?261)?[0-9]{9,10}$/;
    return phoneRegex.test(phoneNumber.replace(/\s/g, ''));
  };

  const validateCard = () => {
    const cleanCardNumber = cardNumber.replace(/\s/g, '');
    if (cleanCardNumber.length < 13 || cleanCardNumber.length > 19) {
      return false;
    }
    let sum = 0;
    let isEven = false;
    for (let i = cleanCardNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cleanCardNumber[i], 10);
      if (isEven) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      sum += digit;
      isEven = !isEven;
    }
    return sum % 10 === 0;
  };

  const processPayment = async () => {
    if (!selectedMethod) {
      Alert.alert('Erreur', 'Veuillez sélectionner une méthode de paiement');
      return;
    }

    if (!amount || parseFloat(amount) <= 0) {
      Alert.alert('Erreur', 'Veuillez entrer un montant valide');
      return;
    }

    if (['airtel', 'mvola', 'orange'].includes(selectedMethod)) {
      if (!phone || !validatePhone(phone)) {
        Alert.alert('Erreur', 'Veuillez entrer un numéro de téléphone valide');
        return;
      }
    }

    if (selectedMethod === 'card') {
      if (!validateCard()) {
        Alert.alert('Erreur', 'Numéro de carte invalide');
        return;
      }
      if (!expiryDate || expiryDate.length < 5) {
        Alert.alert('Erreur', 'Veuillez entrer une date d\'expiration valide');
        return;
      }
      if (!cvv || cvv.length < 3) {
        Alert.alert('Erreur', 'Veuillez entrer un CVV valide');
        return;
      }
      if (!cardHolder) {
        Alert.alert('Erreur', 'Veuillez entrer le nom du titulaire');
        return;
      }
    }

    setLoading(true);

    try {
      const userData = await AsyncStorage.getItem('user');
      const user = userData ? JSON.parse(userData) : null;

      if (!user) {
        Alert.alert('Erreur', 'Veuillez vous connecter pour effectuer un paiement');
        setLoading(false);
        return;
      }

      const paymentData = {
        user_id: user.id,
        repair_id: repair?.id || null,
        amount: parseFloat(amount),
        currency: 'MGA',
        payment_method: selectedMethod,
        phone: selectedMethod !== 'card' ? phone.replace(/\s/g, '') : null,
        card_last_four: selectedMethod === 'card' ? cardNumber.replace(/\s/g, '').slice(-4) : null,
        status: 'pending',
        created_at: new Date().toISOString()
      };

      const response = await fetch(`${API_URL}/payments/initiate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(paymentData)
      });

      const result = await response.json();

      if (result.success) {
        if (['airtel', 'mvola', 'orange'].includes(selectedMethod)) {
          setPaymentResult({
            message: result.message || `Paiement de ${amount} Ariary initié.`,
            ussdCode: result.ussd_code,
            instructions: result.instructions || [
              '1. Composez le code USSD sur votre téléphone',
              '2. Suivez les instructions à l\'écran',
              '3. Validez le paiement avec votre code PIN',
              '4. Attendez la confirmation par SMS'
            ]
          });
          setShowSuccessModal(true);
        } else {
          Alert.alert(
            'Paiement en cours',
            'Traitement de votre paiement par carte...',
            [
              {
                text: 'OK',
                onPress: () => {
                  setPaymentResult({
                    message: `Paiement de ${amount} Ariary effectué avec succès!`,
                    transactionId: result.transaction_id || 'CARD-' + Date.now()
                  });
                  setShowSuccessModal(true);
                }
              }
            ]
          );
        }
      } else {
        Alert.alert('Erreur', result.message || 'Le paiement a échoué');
      }
    } catch (error) {
      console.error('Erreur de paiement:', error);
      Alert.alert('Erreur', 'Une erreur est survenue lors du paiement. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  const getMethodColor = (methodId) => {
    const method = paymentMethods.find(m => m.id === methodId);
    return method?.color || '#666';
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={[COLORS.background, COLORS.card]}
        style={styles.header}
      >
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Paiement</Text>
        <View style={styles.headerSpacer} />
      </LinearGradient>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView style={styles.scrollView}>
          {repair && (
            <View style={styles.repairInfo}>
              <Text style={styles.repairTitle}>Réparation #{repair.id?.substring(0, 8)}</Text>
              <Text style={styles.repairVehicle}>{repair.vehicle?.brand} {repair.vehicle?.model}</Text>
              <Text style={styles.repairStatus}>Statut: {repair.status}</Text>
            </View>
          )}

          <View style={styles.section}>
            <Text style={styles.label}>Montant à payer (Ariary)</Text>
            <View style={styles.amountInputContainer}>
              <Text style={styles.currencySymbol}>Ar</Text>
              <TextInput
                style={styles.amountInput}
                placeholder="0"
                placeholderTextColor="#999"
                value={amount}
                onChangeText={(value) => setAmount(formatAmount(value))}
                keyboardType="numeric"
              />
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Méthode de paiement</Text>
            <View style={styles.methodsGrid}>
              {paymentMethods.map((method) => (
                <TouchableOpacity
                  key={method.id}
                  style={[
                    styles.methodCard,
                    selectedMethod === method.id && styles.methodCardSelected
                  ]}
                  onPress={() => setSelectedMethod(method.id)}
                >
                  <View style={[styles.methodIcon, { backgroundColor: method.color }]}>
                    <Ionicons name={method.icon} size={24} color="#fff" />
                  </View>
                  <Text style={styles.methodName}>{method.name}</Text>
                  {selectedMethod === method.id && (
                    <Ionicons
                      name="checkmark-circle"
                      size={20}
                      color={COLORS.success}
                      style={styles.checkIcon}
                    />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {['airtel', 'mvola', 'orange'].includes(selectedMethod) && (
            <View style={styles.section}>
              <Text style={styles.label}>Numéro de téléphone</Text>
              <View style={styles.phoneInputContainer}>
                <Text style={styles.phonePrefix}>+261</Text>
                <TextInput
                  style={styles.phoneInput}
                  placeholder="34 12 345 67"
                  placeholderTextColor="#999"
                  value={phone}
                  onChangeText={setPhone}
                  keyboardType="phone-pad"
                  maxLength={10}
                />
              </View>
              <Text style={styles.hint}>Entrez le numéro lié à votre compte {paymentMethods.find(m => m.id === selectedMethod)?.name}</Text>
            </View>
          )}

          {selectedMethod === 'card' && (
            <View style={styles.section}>
              <Text style={styles.label}>Informations de la carte</Text>
              
              <Text style={styles.inputLabel}>Numéro de carte</Text>
              <View style={styles.cardInputContainer}>
                <Ionicons name="card" size={20} color="#666" style={styles.inputIcon} />
                <TextInput
                  style={styles.cardInput}
                  placeholder="4242 4242 4242 4242"
                  placeholderTextColor="#999"
                  value={cardNumber}
                  onChangeText={(value) => setCardNumber(formatCardNumber(value))}
                  keyboardType="numeric"
                  maxLength={19}
                />
              </View>

              <Text style={styles.inputLabel}>Titulaire de la carte</Text>
              <View style={styles.cardInputContainer}>
                <Ionicons name="person" size={20} color="#666" style={styles.inputIcon} />
                <TextInput
                  style={styles.cardInput}
                  placeholder="JOHN DOE"
                  placeholderTextColor="#999"
                  value={cardHolder}
                  onChangeText={setCardHolder}
                  autoCapitalize="characters"
                />
              </View>

              <View style={styles.row}>
                <View style={styles.halfColumn}>
                  <Text style={styles.inputLabel}>Expiration</Text>
                  <TextInput
                    style={styles.smallInput}
                    placeholder="MM/YY"
                    placeholderTextColor="#999"
                    value={expiryDate}
                    onChangeText={(value) => setExpiryDate(formatExpiryDate(value))}
                    keyboardType="numeric"
                    maxLength={5}
                  />
                </View>
                <View style={styles.halfColumn}>
                  <Text style={styles.inputLabel}>CVV</Text>
                  <TextInput
                    style={styles.smallInput}
                    placeholder="123"
                    placeholderTextColor="#999"
                    value={cvv}
                    onChangeText={setCvv}
                    keyboardType="numeric"
                    maxLength={4}
                    secureTextEntry
                  />
                </View>
              </View>

              <View style={styles.securityNote}>
                <Ionicons name="lock-closed" size={16} color={COLORS.success} />
                <Text style={styles.securityText}>Vos données sont sécurisées et cryptées</Text>
              </View>
            </View>
          )}

          <TouchableOpacity
            style={[
              styles.payButton,
              (!selectedMethod || !amount || loading) && styles.payButtonDisabled
            ]}
            onPress={processPayment}
            disabled={!selectedMethod || !amount || loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="lock-closed" size={20} color="#fff" style={styles.payIcon} />
                <Text style={styles.payButtonText}>Payer {amount ? parseInt(amount).toLocaleString() : '0'} Ar</Text>
              </>
            )}
          </TouchableOpacity>

          <View style={styles.helpSection}>
            <TouchableOpacity style={styles.helpButton}>
              <Ionicons name="help-circle" size={20} color={COLORS.primary} />
              <Text style={styles.helpText}>Besoin d'aide pour le paiement?</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={showSuccessModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowSuccessModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={[styles.successIcon, { backgroundColor: getMethodColor(selectedMethod) }]}>
              <Ionicons name="checkmark" size={50} color="#fff" />
            </View>
            
            <Text style={styles.modalTitle}>Paiement Initié</Text>
            
            {paymentResult && (
              <>
                <Text style={styles.modalMessage}>{paymentResult.message}</Text>
                
                {paymentResult.ussdCode && (
                  <View style={styles.ussdContainer}>
                    <Text style={styles.ussdLabel}>Code USSD:</Text>
                    <Text style={styles.ussdCode}>{paymentResult.ussdCode}</Text>
                  </View>
                )}
                
                {paymentResult.instructions && (
                  <View style={styles.instructionsContainer}>
                    <Text style={styles.instructionsTitle}>Instructions:</Text>
                    {paymentResult.instructions.map((instruction, index) => (
                      <Text key={index} style={styles.instructionText}>
                        {instruction}
                      </Text>
                    ))}
                  </View>
                )}
                
                {paymentResult.transactionId && (
                  <Text style={styles.transactionId}>
                    Transaction: {paymentResult.transactionId}
                  </Text>
                )}
              </>
            )}
            
            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => {
                setShowSuccessModal(false);
                navigation.navigate('Repairs');
              }}
            >
              <Text style={styles.modalButtonText}>Retour aux réparations</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 15,
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'android' ? 40 : 15
  },
  backButton: {
    padding: 5
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff'
  },
  headerSpacer: {
    width: 34
  },
  keyboardView: {
    flex: 1
  },
  scrollView: {
    flex: 1,
    padding: 20
  },
  repairInfo: {
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  repairTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text
  },
  repairVehicle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 5
  },
  repairStatus: {
    fontSize: 12,
    color: COLORS.success,
    marginTop: 5,
    fontWeight: '600'
  },
  section: {
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 12
  },
  amountInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: 10,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  currencySymbol: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.secondary,
    marginRight: 10
  },
  amountInput: {
    flex: 1,
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.text,
    paddingVertical: 15
  },
  methodsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between'
  },
  methodCard: {
    width: '48%',
    backgroundColor: COLORS.background,
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 2,
    borderColor: 'transparent'
  },
  methodCardSelected: {
    borderColor: COLORS.secondary,
    backgroundColor: COLORS.card
  },
  methodIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8
  },
  methodName: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.text,
    textAlign: 'center'
  },
  checkIcon: {
    position: 'absolute',
    top: 5,
    right: 5
  },
  phoneInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: 10,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  phonePrefix: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginRight: 10
  },
  phoneInput: {
    flex: 1,
    fontSize: 18,
    color: COLORS.text,
    paddingVertical: 15
  },
  hint: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 8,
    fontStyle: 'italic'
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 5,
    marginTop: 10
  },
  cardInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 5,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  inputIcon: {
    marginRight: 10
  },
  cardInput: {
    flex: 1,
    fontSize: 16,
    color: COLORS.text,
    paddingVertical: 12
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10
  },
  halfColumn: {
    width: '48%'
  },
  smallInput: {
    backgroundColor: COLORS.background,
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 16,
    color: COLORS.text,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  securityNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
    padding: 10,
    backgroundColor: COLORS.card,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: COLORS.success
  },
  securityText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginLeft: 8
  },
  payButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5
  },
  payButtonDisabled: {
    backgroundColor: '#666'
  },
  payIcon: {
    marginRight: 10
  },
  payButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold'
  },
  helpSection: {
    marginTop: 20,
    alignItems: 'center'
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  helpText: {
    color: COLORS.primary,
    marginLeft: 8,
    fontSize: 14
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20
  },
  modalContent: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    width: '100%',
    maxWidth: 400,
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 15
  },
  modalMessage: {
    fontSize: 16,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: 20
  },
  ussdContainer: {
    backgroundColor: COLORS.background,
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    width: '100%',
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  ussdLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center'
  },
  ussdCode: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.secondary,
    textAlign: 'center',
    marginTop: 5
  },
  instructionsContainer: {
    backgroundColor: COLORS.background,
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    width: '100%',
    borderWidth: 1,
    borderColor: COLORS.primary
  },
  instructionsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 10
  },
  instructionText: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginBottom: 5
  },
  transactionId: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 20
  },
  modalButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 30,
    width: '100%'
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center'
  }
});

export default PaymentScreen;
