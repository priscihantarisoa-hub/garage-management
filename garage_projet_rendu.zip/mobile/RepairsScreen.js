import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  StatusBar,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
  Linking,
  Platform,
  Animated,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { getRepairs, getStats, getClientRepairs, TEST_MODE } from './api';

const EUR_TO_MGA = 4500;

const COLORS = {
  primary: '#26658C',
  secondary: '#54ACBF',
  light: '#A7EBF2',
  dark: '#023859',
  background: '#011C40',
  card: '#023859',
  text: '#FFFFFF',
  textSecondary: '#A7EBF2',
  orange: '#FF9500',
  green: '#34C759',
  red: '#E50914',
};

// Convert EUR to MGA
const convertToMGA = (eurAmount) => {
  if (!eurAmount || eurAmount === 'Estimation en cours' || eurAmount === 'Payé') return eurAmount;
  const eur = parseFloat(eurAmount.replace('€', ''));
  if (isNaN(eur)) return eurAmount;
  const mga = Math.round(eur * EUR_TO_MGA);
  return mga.toLocaleString() + ' Ar';
};

// Mapper le statut API vers le format de l'app
const mapApiStatusToAppStatus = (apiStatus) => {
  const mapping = {
    'en_attente': 'pending',
    'en_cours': 'progress',
    'termine': 'done',
    'paye': 'done'
  };
  return mapping[apiStatus] || 'pending';
};

// Obtenir la couleur selon le statut API
const getStatusColor = (apiStatus) => {
  const colors = {
    'en_attente': '#FF9500',
    'en_cours': '#E50914',
    'termine': '#34C759',
    'paye': '#26658C'
  };
  return colors[apiStatus] || '#FF9500';
};

// Données de démo pour l'application
const REPAIRS_DATA_DEMO = [
  {
    id: 1,
    vehicle: 'Peugeot 208',
    type: 'Freins',
    status: 'pending',
    statusText: 'En attente',
    location: 'Atelier B',
    price: 'Estimation en cours',
    color: '#FF9500',
    progress: 0,
  },
  {
    id: 2,
    vehicle: 'Renault Clio',
    type: 'Batterie',
    status: 'done',
    statusText: 'Terminé',
    location: 'Sortie',
    price: convertToMGA('120€ à payer'),
    color: '#34C759',
    progress: 100,
  },
  {
    id: 3,
    vehicle: 'Toyota Yaris',
    type: 'Vidange + Filtre',
    status: 'progress',
    statusText: 'En cours',
    location: 'Atelier A',
    price: 'Payé',
    color: '#E50914',
    progress: 65,
  },
];

export default function RepairsScreen({ navigation }) {
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [repairs, setRepairs] = useState([]);
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({
    inProgress: 0,
    completed: 0,
    totalPrice: 0
  });
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [showAssistanceModal, setShowAssistanceModal] = useState(false);

  // Animation refs
  const headerOpacity = useRef(new Animated.Value(0)).current;
  const headerTranslateY = useRef(new Animated.Value(-30)).current;
  const statsOpacity = useRef(new Animated.Value(0)).current;
  const statsTranslateY = useRef(new Animated.Value(30)).current;
  const listOpacity = useRef(new Animated.Value(0)).current;
  const listTranslateY = useRef(new Animated.Value(50)).current;
  const addButtonScale = useRef(new Animated.Value(1)).current;
  const addButtonPulse = useRef(new Animated.Value(0)).current;

  // Start animations
  const startAnimations = () => {
    // Header animation
    Animated.parallel([
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.spring(headerTranslateY, {
        toValue: 0,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();

    // Stats animation (delayed)
    setTimeout(() => {
      Animated.parallel([
        Animated.timing(statsOpacity, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true,
        }),
        Animated.spring(statsTranslateY, {
          toValue: 0,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
      ]).start();
    }, 200);

    // List animation (more delayed)
    setTimeout(() => {
      Animated.parallel([
        Animated.timing(listOpacity, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true,
        }),
        Animated.spring(listTranslateY, {
          toValue: 0,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
      ]).start();
    }, 400);

    // Add button pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(addButtonPulse, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(addButtonPulse, {
          toValue: 0,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  // Add button scale on press
  const handleAddPress = () => {
    Animated.spring(addButtonScale, {
      toValue: 0.9,
      friction: 3,
      tension: 40,
      useNativeDriver: true,
    }).start(() => {
      Animated.spring(addButtonScale, {
        toValue: 1,
        friction: 3,
        tension: 40,
        useNativeDriver: true,
      }).start();
    });
    navigation.navigate('Report');
  };

  useEffect(() => {
    const loadData = async () => {
      try {
        const userData = await AsyncStorage.getItem('user');
        if (userData) {
          setUser(JSON.parse(userData));
        }
        
        if (!TEST_MODE) {
          // Charger depuis l'API réelle
          try {
            const response = await getRepairs();
            if (response.success && response.data.data.length > 0) {
              // Transformer les données de l'API vers le format attendu
              const apiRepairs = response.data.data.map(repair => ({
                id: repair.id,
                vehicle: repair.client ? `${repair.client.voiture_marque} ${repair.client.voiture_modele}` : 'Véhicule',
                type: repair.interventions ? repair.interventions.map(i => i.nom).join(', ') : 'Réparation',
                status: mapApiStatusToAppStatus(repair.statut),
                statusText: repair.statut,
                location: repair.slot ? `Slot ${repair.slot}` : 'En attente',
                price: repair.montant_total ? `${repair.montant_total}€` : 'Estimation en cours',
                color: getStatusColor(repair.statut),
                progress: repair.statut === 'en_cours' ? 50 : (repair.statut === 'termine' ? 100 : 0),
                apiData: repair
              }));
              
              setRepairs(apiRepairs);
              
              const statsResponse = await getStats();
              if (statsResponse.success) {
                setStats({
                  inProgress: statsResponse.data.repairs_in_progress,
                  completed: statsResponse.data.repairs_completed,
                  totalPrice: statsResponse.data.total_amount
                });
              }
            } else {
              // Pas de données, utiliser les données de demo
              setRepairs(REPAIRS_DATA_DEMO);
              setStats({ inProgress: 1, completed: 1, totalPrice: 120 });
            }
          } catch (apiError) {
            console.error('Erreur API:', apiError);
            setRepairs(REPAIRS_DATA_DEMO);
            setStats({ inProgress: 1, completed: 1, totalPrice: 120 });
          }
        } else {
          // Mode test - utiliser les données de demo
          const repairsData = await AsyncStorage.getItem('repairs');
          
          if (repairsData && JSON.parse(repairsData).length > 0) {
            const savedRepairs = JSON.parse(repairsData);
            setRepairs(savedRepairs);
            
            const inProgress = savedRepairs.filter(r => r.status === 'progress').length;
            const completed = savedRepairs.filter(r => r.status === 'done').length;
            const total = savedRepairs
              .filter(r => r.status === 'done')
              .reduce((sum, r) => sum + (r.price || 0), 0);
             
            setStats({
              inProgress: inProgress,
              completed: completed,
              totalPrice: total
            });
          } else {
            setRepairs(REPAIRS_DATA_DEMO);
            setStats({
              inProgress: 1,
              completed: 1,
              totalPrice: 120
            });
          }
        }
        
        setLoading(false);
        setRefreshing(false);
        startAnimations();
        
      } catch (error) {
        console.error('Erreur de chargement:', error);
        setRepairs(REPAIRS_DATA_DEMO);
        setLoading(false);
        setRefreshing(false);
        startAnimations();
      }
    };
    
    loadData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      const repairsData = await AsyncStorage.getItem('repairs');
      if (repairsData && JSON.parse(repairsData).length > 0) {
        const savedRepairs = JSON.parse(repairsData);
        setRepairs(savedRepairs);
        
        const inProgress = savedRepairs.filter(r => r.status === 'progress').length;
        const completed = savedRepairs.filter(r => r.status === 'done').length;
        const total = savedRepairs
          .filter(r => r.status === 'done')
          .reduce((sum, r) => sum + (r.price || 0), 0);
        
        setStats({
          inProgress: inProgress,
          completed: completed,
          totalPrice: total
        });
      }
    } catch (error) {
      console.error('Erreur:', error);
    }
    setRefreshing(false);
  };

  const handleCall = () => {
    setShowPhoneModal(true);
  };

  const handleAssistance = () => {
    setShowAssistanceModal(true);
  };

  const handleMaps = () => {
    if (Platform.OS !== 'web') {
      // Ouvrir Google Maps vers le garage
      const garageLat = 48.8566;
      const garageLng = 2.3522;
      const label = encodeURIComponent('Garage Pro');
      Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${garageLat},${garageLng}&query_place_id=${label}`);
    }
  };

  // Animated card component
  const AnimatedRepairCard = ({ repair, index }) => {
    const cardOpacity = useRef(new Animated.Value(0)).current;
    const cardTranslateY = useRef(new Animated.Value(30)).current;

    useEffect(() => {
      Animated.parallel([
        Animated.timing(cardOpacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.spring(cardTranslateY, {
          toValue: 0,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
      ]).start();
    }, [repair]);

    return (
      <Animated.View
        style={[
          styles.repairCard,
          {
            opacity: cardOpacity,
            transform: [{ translateY: cardTranslateY }],
          },
        ]}
      >
        <TouchableOpacity 
          style={styles.cardTouchable}
          onPress={() => navigation.navigate('RepairDetail', { repair })}
          activeOpacity={0.9}
        >
          <View style={styles.cardTop}>
            <View style={styles.vehicleInfo}>
              <View style={styles.vehicleIcon}>
                <Animated.View 
                  style={[
                    styles.vehicleIconAnimated,
                    { transform: [{ rotate: repair.status === 'progress' ? '360deg' : '0deg' }] }
                  ]}
                >
                  <Ionicons name="car" size={20} color="#FFFFFF" />
                </Animated.View>
              </View>
              <View>
                <Text style={styles.vehicleName}>{repair.vehicle}</Text>
                <Text style={styles.repairType}>{repair.type}</Text>
              </View>
            </View>
            <Animated.View 
              style={[
                styles.statusBadge, 
                { 
                  backgroundColor: `${repair.color}20`,
                  transform: [{ scale: 1 }]
                }
              ]}
            >
              <Text style={[styles.statusText, { color: repair.color }]}>
                {repair.statusText}
              </Text>
            </Animated.View>
          </View>

          <View style={styles.cardDivider} />

          <View style={styles.cardBottom}>
            <View style={styles.cardInfo}>
              <Ionicons name="location-outline" size={16} color="#666" />
              <Text style={styles.cardInfoText}>{repair.location}</Text>
            </View>
            <View style={styles.cardInfo}>
              <Ionicons name="pricetag-outline" size={16} color="#666" />
              <Text style={[styles.cardInfoText, { color: repair.status === 'done' && repair.price.includes('à payer') ? '#46d369' : '#B3B3B3' }]}>
                {repair.price}
              </Text>
            </View>
          </View>

          {repair.status === 'progress' && (
            <Animated.View style={styles.progressContainer}>
              <View style={styles.progressBar}>
                <Animated.View 
                  style={[
                    styles.progressFill, 
                    { 
                      width: `${repair.progress}%`, 
                      backgroundColor: repair.color,
                    }
                  ]} 
                />
              </View>
              <Text style={styles.progressText}>{repair.progress}%</Text>
            </Animated.View>
          )}
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#141414" />
      
      {/* Header with animation */}
      <Animated.View 
        style={[
          styles.header,
          {
            opacity: headerOpacity,
            transform: [{ translateY: headerTranslateY }],
          }
        ]}
      >
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>Bonjour</Text>
            <Text style={styles.userName}>{user?.name || user?.email?.split('@')[0] || 'Client'}</Text>
          </View>
          <View style={styles.headerActions}>
            <View style={styles.addButtonContainer}>
              <TouchableOpacity 
                style={styles.addButton}
                onPress={handleAddPress}
                activeOpacity={1}
              >
                <Animated.View 
                  style={[
                    styles.addButtonInner,
                    {
                      transform: [
                        { scale: addButtonScale },
                        {
                          shadowOpacity: addButtonPulse.interpolate({
                            inputRange: [0, 1],
                            outputRange: [0.4, 0.8],
                          }),
                        },
                      ],
                    }
                  ]}
                >
                  <Ionicons name="add" size={28} color="white" />
                </Animated.View>
              </TouchableOpacity>
              <Text style={styles.addButtonLabel}>Déposer une panne</Text>
            </View>
          </View>
        </View>
      </Animated.View>

      {/* Stats Cards with animation */}
      <Animated.View 
        style={[
          styles.statsContainer,
          {
            opacity: statsOpacity,
            transform: [{ translateY: statsTranslateY }],
          }
        ]}
      >
        <Animated.View style={styles.statCard}>
          <Animated.View 
            style={[
              styles.statIcon, 
              { 
                backgroundColor: '#E5091420',
                transform: [{ scale: 1 }]
              }
            ]}
          >
            <Ionicons name="car-outline" size={24} color="#E50914" />
          </Animated.View>
          <Text style={styles.statNumber}>{stats.inProgress}</Text>
          <Text style={styles.statLabel}>En cours</Text>
        </Animated.View>
        
        <Animated.View style={styles.statCard}>
          <Animated.View 
            style={[
              styles.statIcon, 
              { 
                backgroundColor: '#46d36920',
                transform: [{ scale: 1 }]
              }
            ]}
          >
            <Ionicons name="checkmark-done-outline" size={24} color="#34C759" />
          </Animated.View>
          <Text style={styles.statNumber}>{stats.completed}</Text>
          <Text style={styles.statLabel}>Terminés</Text>
        </Animated.View>
        
        <Animated.View style={styles.statCard}>
          <Animated.View 
            style={[
              styles.statIcon, 
              { 
                backgroundColor: '#34C75920',
                transform: [{ scale: 1 }]
              }
            ]}
          >
            <Ionicons name="wallet-outline" size={24} color="#FF9500" />
          </Animated.View>
          <Text style={styles.statNumber}>{stats.totalPrice.toLocaleString()} Ar</Text>
          <Text style={styles.statLabel}>Total</Text>
        </Animated.View>
      </Animated.View>

      {/* Section Title */}
      <Animated.View 
        style={[
          styles.sectionHeader,
          {
            opacity: statsOpacity,
          }
        ]}
      >
        <Text style={styles.sectionTitle}>Mes Réparations</Text>
        <Text style={styles.sectionSubtitle}>{repairs.length} véhicule{repairs.length > 1 ? 's' : ''}</Text>
      </Animated.View>

      {/* Repairs List */}
      <Animated.View 
        style={[
          styles.scrollContainer,
          {
            opacity: listOpacity,
            transform: [{ translateY: listTranslateY }],
          }
        ]}
      >
        <ScrollView 
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl 
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#E50914"
              colors={['#E50914']}
            />
          }
        >
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#E50914" />
              <Text style={styles.loadingText}>Chargement...</Text>
            </View>
          ) : repairs.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="car-sport-outline" size={64} color="#404040" />
              <Text style={styles.emptyTitle}>Aucune réparation</Text>
              <Text style={styles.emptySubtitle}>Déposez votre première demande</Text>
              <TouchableOpacity 
                style={styles.emptyButton}
                onPress={() => navigation.navigate('Report')}
              >
                <Text style={styles.emptyButtonText}>Nouvelle réparation</Text>
              </TouchableOpacity>
            </View>
          ) : (
            repairs.map((repair, index) => (
              <AnimatedRepairCard 
                key={repair.id} 
                repair={repair} 
                index={index}
              />
            ))
          )}

          {/* Quick Actions */}
          <Animated.View style={styles.quickActions}>
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={handleCall}
              activeOpacity={0.7}
            >
              <View style={styles.quickActionIcon}>
                <Ionicons name="call-outline" size={24} color="#E50914" />
              </View>
              <Text style={styles.quickActionText}>Appeler</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={handleAssistance}
              activeOpacity={0.7}
            >
              <View style={styles.quickActionIcon}>
                <Ionicons name="medkit-outline" size={24} color="#E50914" />
              </View>
              <Text style={styles.quickActionText}>Assistance</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={handleMaps}
              activeOpacity={0.7}
            >
              <View style={styles.quickActionIcon}>
                <Ionicons name="map-outline" size={24} color="#E50914" />
              </View>
              <Text style={styles.quickActionText}>Maps</Text>
            </TouchableOpacity>
          </Animated.View>

          {/* Phone Modal */}
          {showPhoneModal && (
            <View style={styles.modalOverlay}>
              <View style={styles.modalContent}>
                <View style={styles.modalIcon}>
                  <Ionicons name="call" size={40} color="#E50914" />
                </View>
                <Text style={styles.modalTitle}>Numéro du garage</Text>
                <Text style={styles.modalPhone}>01 23 45 67 89</Text>
                <TouchableOpacity 
                  style={styles.modalCallButton}
                  onPress={() => {
                    setShowPhoneModal(false);
                    if (Platform.OS !== 'web') {
                      Linking.openURL('tel:0123456789');
                    }
                  }}
                >
                  <Text style={styles.modalCallButtonText}>Appeler</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.modalCloseButton}
                  onPress={() => setShowPhoneModal(false)}
                >
                  <Text style={styles.modalCloseButtonText}>Fermer</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Assistance Modal */}
          {showAssistanceModal && (
            <View style={styles.modalOverlay}>
              <View style={styles.assistanceModalContent}>
                <View style={styles.assistanceModalIcon}>
                  <Ionicons name="medkit" size={40} color="#E50914" />
                </View>
                <Text style={styles.assistanceModalTitle}>Services d'assistance</Text>
                
                <View style={styles.assistanceServices}>
                  <TouchableOpacity 
                    style={styles.assistanceServiceButton}
                    onPress={() => {
                      setShowAssistanceModal(false);
                      navigation.navigate('Report');
                    }}
                  >
                    <Ionicons name="document-text-outline" size={24} color="#E50914" />
                    <Text style={styles.assistanceServiceText}>Déposer une demande</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={styles.assistanceServiceButton}
                    onPress={() => {
                      setShowAssistanceModal(false);
                      if (Platform.OS !== 'web') {
                        Linking.openURL('tel:0123456789');
                      }
                    }}
                  >
                    <Ionicons name="call-outline" size={24} color="#E50914" />
                    <Text style={styles.assistanceServiceText}>Contact urgent</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={styles.assistanceServiceButton}
                    onPress={() => {
                      setShowAssistanceModal(false);
                      if (Platform.OS !== 'web') {
                        const garageLat = 48.8566;
                        const garageLng = 2.3522;
                        const label = encodeURIComponent('Garage Pro');
                        Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${garageLat},${garageLng}&query_place_id=${label}`);
                      }
                    }}
                  >
                    <Ionicons name="location-outline" size={24} color="#E50914" />
                    <Text style={styles.assistanceServiceText}>Nous-localiser</Text>
                  </TouchableOpacity>
                </View>
                
                <TouchableOpacity 
                  style={styles.modalCloseButton}
                  onPress={() => setShowAssistanceModal(false)}
                >
                  <Text style={styles.modalCloseButtonText}>Fermer</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          <View style={styles.bottomSpacer} />
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  userName: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 2,
  },
  addButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  addButtonInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  addButtonLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 6,
    textAlign: 'center',
    fontWeight: '500',
  },
  addButtonContainer: {
    alignItems: 'center',
  },
  headerActions: {
    marginLeft: 'auto',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statIconAnimated: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.text,
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    marginTop: 24,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: COLORS.text,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: COLORS.secondary,
  },
  scrollContainer: {
    flex: 1,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  loadingText: {
    color: COLORS.textSecondary,
    marginTop: 12,
    fontSize: 14,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: COLORS.secondary,
    marginTop: 4,
  },
  emptyButton: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 24,
  },
  emptyButtonText: {
    color: COLORS.text,
    fontWeight: '600',
    fontSize: 16,
  },
  repairCard: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.primary,
    overflow: 'hidden',
  },
  cardTouchable: {
    padding: 20,
  },
  cardTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  vehicleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  vehicleIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleIconAnimated: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleName: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
  },
  repairType: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  cardDivider: {
    height: 1,
    backgroundColor: COLORS.primary,
    marginVertical: 16,
  },
  cardBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  cardInfoText: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: COLORS.primary,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginLeft: 10,
    width: 40,
    textAlign: 'right',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 16,
    marginTop: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  quickActionButton: {
    alignItems: 'center',
    padding: 8,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  quickActionText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  bottomSpacer: {
    height: 20,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContent: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
    width: '80%',
  },
  modalIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 10,
  },
  modalPhone: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.secondary,
    marginBottom: 24,
    fontFamily: 'monospace',
  },
  modalCallButton: {
    backgroundColor: COLORS.success,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 40,
    width: '100%',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalCallButtonText: {
    color: COLORS.text,
    fontSize: 16,
    fontWeight: '700',
  },
  modalCloseButton: {
    paddingVertical: 12,
    width: '100%',
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },
  assistanceModalContent: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
    width: '85%',
  },
  assistanceModalIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  assistanceModalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 20,
    textAlign: 'center',
  },
  assistanceServices: {
    width: '100%',
    gap: 12,
    marginBottom: 20,
  },
  assistanceServiceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  assistanceServiceText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginLeft: 14,
  },
});
