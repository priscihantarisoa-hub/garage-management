# 🚗 Garage Simulator - Godot Game

## Description
Jeu de simulation de garage où vous devez réparer des voitures en gérant 3 slots de réparation.

## 🎮 Contrôles

| Touche | Action |
|--------|--------|
| **Tab** | Sélectionner la prochaine voiture |
| **Z/Q/S/D** ou **W/A/S/D** | Déplacer la voiture |
| **E** | Interagir avec une voiture |
| **1-8** | Sélectionner une réparation dans le menu |
| **Espace** | Placer la voiture dans un slot |

## 🎯 Objectifs du Jeu

1. **Sélectionner** une voiture dans la cour (zone libre)
2. **Déplacer** la voiture vers un slot de réparation (vert = libre, rouge = occupé)
3. **Placer** la voiture dans un slot avec **Espace**
4. **Réparer** en vous approchant de la voiture et appuyant sur **E**
5. **Sélectionner** le type de réparation (touches 1-8)
6. **Attendre** la barre de progression
7. **Répéter** pour toutes les réparations
8. **Collecter** l'argent quand le client vient payer

## 🔧 Types de Réparations (8 types)

| Touche | Réparation | Prix | Temps |
|--------|------------|------|-------|
| **1** | Frein | 80€ | 10s |
| **2** | Vidange | 50€ | 8s |
| **3** | Filtre | 30€ | 5s |
| **4** | Batterie | 100€ | 7s |
| **5** | Amortisseurs | 150€ | 12s |
| **6** | Embrayage | 200€ | 15s |
| **7** | Pneus | 120€ | 9s |
| **8** | Refroidissement | 130€ | 11s |

## 🏗️ Architecture du Projet

```
jeu-godot/
├── assets/
│   ├── cars/          # Images des voitures
│   ├── characters/     # Personnages
│   └── garage/         # Éléments du garage
├── *.gd               # Scripts principaux
├── *.tscn             # Scènes Godot
└── project.godot      # Configuration du projet
```

## 📡 Intégration API (Optionnel)

Le jeu peut être connecté à l'API Laravel pour synchroniser les données :

```javascript
// API Endpoint
GET http://localhost:8000/api/repairs/active
GET http://localhost:8000/api/repairs/stats
POST http://localhost:8000/api/payments/pay/{id}
```

## 🎨 Graphismes

- **Voitures** : 12 modèles différents dans `assets/cars/`
- **Garage** : Éléments visuels dans `assets/garage/`
- **Slots** : 3 zones de réparation avec indicateurs de couleur

## 💰 Système de Jeu

- **Slots** : Maximum 3 voitures en réparation simultanément
- **Argent** : Géré par l'UI, augmenté lors des paiements
- **Progression** : Barre de progression pour chaque réparation
- **Clients** : Les voitures terminées attendent le paiement

## 🐛 Débogage

Activer les logs dans la console Godot :
```gdscript
print("💰 UI: " + str(argent) + "€")
```

## 📋 État des Fonctionnalités

| Fonctionnalité | État |
|----------------|------|
| Sélection voiture | ✅ Complet |
| Déplacement ZQSD | ✅ Complet |
| Placement slots | ✅ Complet |
| Menu réparations | ✅ Complet |
| Barre progression | ✅ Complet |
| Système paiement | ✅ Complet |
| Synchronisation API | ⚠️ Optionnel |
| Audio | ❌ À ajouter |

## 🚀 Lancer le Jeu

1. Ouvrir Godot Engine (4.x)
2. Importer le projet `jeu-godot/`
3. Cliquer sur "Play" (F5)
4. Enjoy! 🎮
